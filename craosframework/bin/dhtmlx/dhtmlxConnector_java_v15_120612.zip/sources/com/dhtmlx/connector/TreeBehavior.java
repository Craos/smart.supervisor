package com.dhtmlx.connector;

public class TreeBehavior extends ConnectorBehavior {

}

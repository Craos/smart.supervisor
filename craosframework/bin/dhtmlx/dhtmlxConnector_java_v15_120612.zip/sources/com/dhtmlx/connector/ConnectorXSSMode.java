package com.dhtmlx.connector;

public class ConnectorXSSMode {

	public static int DHX_SECURITY_TRUSTED = 1;
	public static int DHX_SECURITY_SAFETEXT = 2;
	public static int DHX_SECURITY_SAFEHTML = 3;

}

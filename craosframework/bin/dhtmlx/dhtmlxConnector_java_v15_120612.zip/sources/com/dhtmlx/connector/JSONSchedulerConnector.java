package com.dhtmlx.connector;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class JSONSchedulerConnector extends SchedulerConnector {

	/**
	 * Instantiates a new scheduler connector.
	 * 
	 * @param db the db connection
	 */
	public JSONSchedulerConnector(Connection db){
		this(db,DBType.Custom);
	}

	/**
	 * Instantiates a new scheduler connector.
	 * 
	 * @param db the db connection
	 * @param db_type the db type
	 */
	public JSONSchedulerConnector(Connection db, DBType db_type){
		this(db,db_type, new JSONSchedulerFactory());
	}
	
	/**
	 * Instantiates a new scheduler connector.
	 * 
	 * @param db the db connection
	 * @param db_type the db type
	 * @param a_factory the class factory, which will be used by object
	 */
	public JSONSchedulerConnector(Connection db, DBType db_type, BaseFactory a_factory){
		this(db,db_type,a_factory,a_factory.createRenderStrategy());
	}

	/**
	 * Instantiates a new scheduler connector.
	 * 
	 * @param db the db connection
	 * @param db_type the db type
	 * @param a_factory the class factory, which will be used by object
	 * @param render_type the render class, which will be used to render items
	 */
	public JSONSchedulerConnector(Connection db, DBType db_type, BaseFactory a_factory, RenderStrategy render_type){
		super(db,db_type,a_factory,render_type);
	}

	protected String xml_start() {
		return "{\"data\":";
	}

	protected String xml_end() {
		fill_collections();
		String end = (extra_output.length()>=0) ? extra_output.toString() : "";
		end += top_attributes_json() + "}";
		return end;
	}

	protected String output_as_xml(ConnectorResultSet result) throws ConnectorOperationException{
		ConnectorOutputWriter out = new ConnectorOutputWriter(xml_start(), render_set(result) + xml_end());
		output_as_xml(out.toString());
		return out.toString();
	}

	public void output_as_xml(String data){
 		http_response.reset();
		http_response.addHeader("Content-type", "text/javascript;charset=" + encoding);
		
		try {
			java.io.Writer out = http_response.getWriter();
			out.write(data);
			out.close();
			http_response.flushBuffer();
		} catch (IOException e){
			LogManager.getInstance().log("Error during data outputing");
			LogManager.getInstance().log(e.getMessage());
		}
		end_run();
	}
	
	
	/**
	 * Fill collections of options with data from DB
	 */
	protected void fill_collections(){
		ArrayList<String> result = new ArrayList<String>();
		Iterator<String> key = options.keySet().iterator();
		while (key.hasNext()){
			String name = key.next();
			BaseConnector option_connector = options.get(name);
			String data = option_connector.render();
			result.add("\"" + name + "\":" + data);
		}
		String collections = ConnectorUtils.join(result.toArray(), ", ");
	    if (collections.length() > 0)
	    	collections = ",\"collections\": {" + collections + "}";

	    extra_output.append(collections);
	}


	/**
	 * Define connector for options retrieving 
	 * 
	 * @param name the name of column
	 * @param connector the connector
	 */
	public void set_options(String name, BaseConnector connector){
		options.put(name,connector);
	}
	
	/**
	 * Define fixed list of options
	 * 
	 * @param name the name of column
	 * @param object the iterable object ( array ) 
	 */
	@SuppressWarnings("unchecked")
	public void set_options(String name, Iterable object){
		Iterator it = object.iterator();
		StringBuffer data = new StringBuffer();
		
		while (it.hasNext()){
			String value = it.next().toString();
			data.append("<item value='"+value+"' label='"+value+"' />");
		}
		set_options(name,new DummyStringConnector(data.toString()));
	}
	
	/**
	 * Define fixed list of options
	 * 
	 * @param name the name of column
	 * @param object the hash object
	 */
	@SuppressWarnings("unchecked")
	public void set_options(String name, HashMap object){
		Iterator it = object.keySet().iterator();
		StringBuffer data = new StringBuffer();
		
		while (it.hasNext()){
			Object value = it.next();
			Object label = object.get(value).toString();
			data.append("<item value='"+value.toString()+"' label='"+label.toString()+"' />");
		}
		set_options(name,new DummyStringConnector(data.toString()));
	}
}

dhtmlxConnector for Java v.1.5

Java Version required: 1.5+
Online Documentation: http://www.dhtmlx.com/dhxdocs/doku.php?id=dhtmlxconnectorjava:toc

(c) Dinamenta, UAB
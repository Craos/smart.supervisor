DHTMLX Quick Tables. v.1.1 build 101101. Distributed under the GNU GPL

This utility allows you to create DHTML table based on some database table using simple wizard. 
Table can be readonly or editable (changes are saved back to the database). Special technology allows loading big amount of data very fast.

Supported databases:

- MySQL
- PostgreSQL
- MSSQL
- Oracle

Installation notes:

- If you've downloaded the package with single file inside - install.php, you need just upload this file into some folder on your web server (PHP support is required) and load it in the browser. It will unpack necessary files into the folder you uploaded install.php to and run the wizard.

- If you've downloaded the package which contains sources of Quick Tables, then you need to upload the content of the package into some folder on your web server (PHP support is required) and load index.php in the browser. It will run the wizard.

You can find more instructions here: http://www.dhtmlx.com/blog/?p=144

(c) DHTMLX Ltd. - Provider of JavaScript library that offers essential functionality for building cross-browser, Ajax-based user interfaces
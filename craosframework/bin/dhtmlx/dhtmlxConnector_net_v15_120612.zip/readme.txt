dhtmlxConnector for .Net v.1.5

dhtmlxConnectors.NET are built using Microsoft .NET Framework 3.5


IMPORTANT: 
	Samples project is using Standard version of dhtmlx components, 
	which allows to use all functionality except of TreeGrid. 
	If you want to use PRO version of components, just replace 
	"samples/dhtmlx/dhtmlx.js" with related file from PRO package

Online documentation: http://docs.dhtmlx.com/doku.php?id=dhtmlxconnectornet:toc

(c) Dinamenta, UAB
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxChart
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class _02_custom_sql_query : dhtmlxRequestHandler
    {
       public override IdhtmlxConnector CreateConnector(HttpContext context)
        {
            var connector = new dhtmlxChartConnector(
                "SELECT id, sales, year FROM Sales",
                "id",
                dhtmlxDatabaseAdapterType.SqlServer2005,
                ConfigurationManager.ConnectionStrings["SamplesDatabase"].ConnectionString
            );

            return connector;
        }
    }
}
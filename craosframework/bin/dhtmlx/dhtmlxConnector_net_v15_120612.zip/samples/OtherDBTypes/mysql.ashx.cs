using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxGrid
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class mysql : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {
            dhtmlxGridConnector connector = new dhtmlxGridConnector(
                "dhx_users",
                "login",
                "id",
                dhtmlxDatabaseAdapterType.Odbc,
                ConfigurationManager.ConnectionStrings["ODBC"].ConnectionString
            );
            if (context.Request.QueryString["dynamic"] != null)
                connector.SetDynamicLoading(Convert.ToInt32(context.Request.QueryString["dynamic"]));
            return connector;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxGrid
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class oracle1 :  dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {
            dhtmlxGridConnector connector = new dhtmlxGridConnector(          
             "SELECT  author, title,   'EPC' AS Family, 'Total' AS Total, SUM(sales) AS sales FROM BookStore WHERE (book_id > 1) AND (instore = 1) GROUP BY author, title",
             "",
                dhtmlxDatabaseAdapterType.Oracle,
                ConfigurationManager.ConnectionStrings["Oracle"].ConnectionString

    
            );
            if (context.Request.QueryString["dynamic"] != null)
                connector.SetDynamicLoading(Convert.ToInt32(context.Request.QueryString["dynamic"]));
            return connector;
        }
    }
}

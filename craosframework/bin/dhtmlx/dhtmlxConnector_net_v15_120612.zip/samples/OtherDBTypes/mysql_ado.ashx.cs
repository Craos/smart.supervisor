using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxGrid
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class mysql_ado : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {
            dhtmlxGridConnector connector = new dhtmlxGridConnector(
                "dhx_users",
                "id, login",
                "id",
                dhtmlxDatabaseAdapterType.MySQL,
                ConfigurationManager.ConnectionStrings["MySql"].ConnectionString

    
            );
            if (context.Request.QueryString["dynamic"] != null)
                connector.SetDynamicLoading(Convert.ToInt32(context.Request.QueryString["dynamic"]));
            return connector;
        }
    }
}

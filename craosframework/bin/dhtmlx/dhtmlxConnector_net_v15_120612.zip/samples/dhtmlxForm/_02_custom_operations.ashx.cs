﻿using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxForm
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class form_custom_connector : dhtmlxRequestHandler
    {
        public void null_BeforeUpdate(object sender, DataActionProcessingEventArgs e)
        {

            if (e.DataAction.Data[new TableField("title", "TITL")] == "")
                e.DataAction.Data[new TableField("title", "TITL")] = null;
            if (e.DataAction.Data[(TableField)"author"] == "")
                e.DataAction.Data[(TableField)"author"] = null;
        }

        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {
            var connector = new dhtmlxFormConnector(
                "SELECT title as TITL, author, price FROM BookStore",
                "book_id",
                dhtmlxDatabaseAdapterType.SqlServer2005,
                ConfigurationManager.ConnectionStrings["SamplesDatabase"].ConnectionString
            );

            connector.Request.BeforeUpdate += new System.EventHandler<DataActionProcessingEventArgs>(null_BeforeUpdate);

            connector.Request.CustomSQLs.Add(CustomSQLType.Update,
                @"UPDATE BookStore SET title = '{TITL}', author = '{author}', price = '{price}' WHERE book_id='{book_id}'; "
            );         

            return connector;
        }
         
    }
}
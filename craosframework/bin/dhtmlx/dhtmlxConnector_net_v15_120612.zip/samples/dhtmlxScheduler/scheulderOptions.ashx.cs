﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxScheduler
{
    /// <summary>
    /// Summary description for scheulderOptions
    /// </summary>
    public class scheulderOptions : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {
            var connector = new dhtmlxSchedulerConnector(
                  "Events"
                , "EventID"
                , dhtmlxDatabaseAdapterType.SqlServer2005
                , ConfigurationManager.ConnectionStrings["SamplesDatabase"].ConnectionString
                , "FromDate"
                , "ToDate"
                , "Subject as text, Details as details, Tags"
            );
               dhtmlxOptionsConnector optionsConnector = new dhtmlxOptionsConnector("types", "typeid",connector.Request.Adapter, "name");
               connector.AddOptionsConnector("type", optionsConnector);
            return connector;
        }
    }
}
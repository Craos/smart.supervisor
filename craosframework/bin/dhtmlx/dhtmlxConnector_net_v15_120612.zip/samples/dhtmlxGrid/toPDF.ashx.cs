﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxGrid
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class toPDF : dhtmlxRequestHandler
    {
        void connector_ItemPrerender(object sender, ItemPrerenderEventArgs<dhtmlxGridDataItem> e)
        {
            e.DataItem.DataFields.Remove("book_id");
        }
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {

            var config = new dhtmlxGridConfiguration();
            config.SetHeader("Sales,Title,Author,Price,Incstore,shipping,bestseller,Publication");
            config.AttachHeader("NEw,, sss,Price,Incstore,shipping,bestseller,Publication", ",colspan='2',,rowspan='2',,,");
            config.AttachHeader("1,2,3,4,5,6,7,8");
            config.SetInitWidths("120,250,200,100,30,100,30,100");
            config.SetColSorting("na,na,na,na,na,na,na,na");
          
         
            config.SetColTypes("ro,ed,ro,ro,ch,ro,ch,ro");
            config.SetColAlign("center,center,center");
          

            dhtmlxGridConnector connector = new dhtmlxGridConnector(
                "BookStore",
                "sales, title, author, price, instore, shipping, bestseller, pub_date",
                "book_id",
                dhtmlxDatabaseAdapterType.SqlServer2005,
                ConfigurationManager.ConnectionStrings["SamplesDatabase"].ConnectionString
            );
            connector.SetConfig(config);
            var convert = new ConvertService(connector, "http://dhtmlxgrid.appspot.com/export/pdf");
            convert.PDF();

            connector.ItemPrerender += new EventHandler<ItemPrerenderEventArgs<dhtmlxGridDataItem>>(connector_ItemPrerender);
            return connector;
        }

        
    }
}

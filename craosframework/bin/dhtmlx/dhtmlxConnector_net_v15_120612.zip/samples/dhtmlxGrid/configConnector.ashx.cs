using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.dhtmlxGrid
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class configConnector : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {
            var config = new dhtmlxGridConfiguration();
            config.SetHeader("Item,#cspan");
            config.AttachHeader("Sales,Title");
	        config.SetColIds("col1,col2");
	        config.SetInitWidths("120,*");
	        config.SetColSorting("connector,connector");
            config.SetColColor(",#d5f1ff");
	        config.SetColHidden("false,false");
	        config.SetColTypes("ro,ed");
	        config.SetColAlign("center,center");
	        config.SetColVAlign("bottom,middle");
            

            dhtmlxGridConnector connector = new dhtmlxGridConnector(
                "BookStore",
                "sales, title",
                "book_id",
                dhtmlxDatabaseAdapterType.SqlServer2005,
                ConfigurationManager.ConnectionStrings["SamplesDatabase"].ConnectionString
            );
            connector.SetConfig(config);
         
            return connector;
        }

        
    }
}

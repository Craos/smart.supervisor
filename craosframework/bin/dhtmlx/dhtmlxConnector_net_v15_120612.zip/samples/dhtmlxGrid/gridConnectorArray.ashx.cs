
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;
using dhtmlxConnector.Net_Samples.Linq;
namespace dhtmlxConnector.Net_Samples.dhtmlxGrid
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class gridConnectorArray : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {

            var data = new DHTMLXDataContext();
            var connector = new dhtmlxGridConnector(data.BookStores, "sales, title, author, price, instore, shipping, bestseller, pub_date", "book_id");

            return connector;
        }
  

    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using dhtmlxConnectors;
using System.Configuration;
using dhtmlxConnector.Net_Samples.Linq;
namespace dhtmlxConnector.Net_Samples.dhtmlxTree
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ObjSource : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {


            var data = new DHTMLXDataContext();
          /*  var items = new List<object>
            {
                new {item_id = 1, item_parent_id = "0", item_nm = "text_1"},
                new {item_id = 2, item_parent_id = "1", item_nm = "#2 child of 1"},
                new {item_id = 3, item_parent_id = "1", item_nm = "child of 1"},
                new {item_id = 4, item_parent_id = "0", item_nm = "text_4"},
                new {item_id = 5, item_parent_id = "2", item_nm = "#5 child of #2"},
                new {item_id = 6, item_parent_id = "5", item_nm = "child of 5"},
                new {item_id = 7, item_parent_id = "0", item_nm = "text_7"},
            };*/

            var connector = new dhtmlxTreeConnector(data.Folders, "item_id", "item_nm", "item_parent_id");

            connector.RootItemRelationIDValue = "0"; //Set ParentID value for root items
            return connector;
        }
    }
}

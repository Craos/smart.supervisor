﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("dhtmlxConnector.Net Samples")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Dinamenta, UAB")]
[assembly: AssemblyProduct("dhtmlxConnectors.NET Samples")]
[assembly: AssemblyCopyright("Copyright © Dinamenta, UAB 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("3d5900ae-111a-45be-96b3-d9e4606ca793")]

[assembly: AssemblyVersion("0.9.8.1")]
[assembly: AssemblyFileVersion("0.9.8.1")]


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using dhtmlxConnectors;
using System.Web.Services;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.Combo
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class _3_array_connector : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {

            var items = new List<object>
            {
                  new {key="1", value="value 1"}
                , new {key="2", value="value 2"}
                , new {key="3", value="value 3"}
                , new {key="4", value="value 4"}
                , new {key="5", value="value 5"}

            };

            var connector = new dhtmlxComboConnector(items, "key", "value");          
            return connector;
        }
    }
}
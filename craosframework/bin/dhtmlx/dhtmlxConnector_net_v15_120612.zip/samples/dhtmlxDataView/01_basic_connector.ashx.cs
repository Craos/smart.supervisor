
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using dhtmlxConnectors;
using System.Web.Services;
using System.Configuration;

namespace dhtmlxConnector.Net_Samples.DataView
{
    /// <summary>
    /// Connector body
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class _1_basic_connector : dhtmlxRequestHandler
    {
        public override IdhtmlxConnector CreateConnector(HttpContext context)
        {

            dhtmlxDataViewConnector connector = new dhtmlxDataViewConnector(
                "Country",
                "ISO,Name,PrintableName,Numcode",
                "UID",
                dhtmlxDatabaseAdapterType.SqlServer2005,
                ConfigurationManager.ConnectionStrings["SamplesDatabase"].ConnectionString
            );
            return connector;
        }
    }
}
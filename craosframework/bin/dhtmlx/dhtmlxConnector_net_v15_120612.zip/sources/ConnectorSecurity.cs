﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HtmlAgilityPack;
using System.Text.RegularExpressions;
using System.Web;
namespace dhtmlxConnectors
{
    /// <summary>
    /// Class that handles XSS and CSRF security
    /// </summary>
    public static class ConnectorSecurity
    {
        /// <summary>
        /// Defines if connectors should sign requests to prevent CSRF attacks
        /// </summary>
        public static bool SecurityKey { get; set; }
        
        /// <summary>
        /// Input data sanitization policy modes
        /// </summary>
        public enum SecutiryXSS
        {
            /// <summary>
            /// Remove html from input data
            /// </summary>
            DHX_SECURITY_SAFETEXT,
            /// <summary>
            /// Remove dangerous html elements only
            /// </summary>
            DHX_SECURITY_SAFEHTML,
            /// <summary>
            /// Do not escape input
            /// </summary>
            DHX_SECURITY_TRUSTED
        }
        /// <summary>
        /// Input data sanitization policy
        /// </summary>
        public static SecutiryXSS XSS { get; set; }

        /// <summary>
        /// Check request for CSRF attack
        /// </summary>
        /// <param name="type"></param>
        public static void CheckCSRF(DataRequestType type)
        {
            if (ConnectorSecurity.SecurityKey)
            {
                CSRFSequrity.CheckCSRF(type);
            }
        }

        static ConnectorSecurity()
        {
            for (var i = 0; i < tagsWhitelist.Length; i++)
            {
                tagsWhitelist[i] = tagsWhitelist[i].ToUpper();
            }
            for (var i = 0; i < attributesWhitelist.Length; i++)
            {
                attributesWhitelist[i] = attributesWhitelist[i].ToUpper();
            }
            Array.Sort<string>(tagsWhitelist);
            Array.Sort<string>(attributesWhitelist);

        }

        private static readonly string[] tagsWhitelist =
            new string[] {
						 "!DOCTYPE", "#DOCUMENT", "#TEXT",	
						 "A", "ACRONYM", "ADDRESS", "AREA", "B", 
						 "BASEFONT", "BDO", "BIG", "BLOCKQUOTE", "BODY", "BR", "CAPTION",
						 "CENTER", "CITE", "CODE", "COL", "COLGROUP", "STRONG","DD", "DEL", "DFN",
						 "DIR", "DIV", "DL", "EM", "FONT", "HEAD", "H1", "H2", "H3", "H4",
						 "H5", "H6", "HR", "HTML", "I", "IMG", "INS", "KBD", "LABEL",
						 "LI", "LISTING", "MAP", "MARQUEE", "MENU", "NOBR", 
						 "OL", "P", "PRE", "Q", "RT",  "S", "SAMP", "SMALL", "SPAN",
						 "STRIKE", "STRONG", "SUB", "SUP", "TABLE", "TBODY", "TD", "TFOOT",
						 "TH", "THEAD",  "TR", "TT", "U", "UL", "VAR", "WBR", "XMP"
					 };

        private static readonly string[] attributesWhitelist =
            new string[] {
						 "ABBR", "ADDITIVE", "ALIGN", "ALLOWTRANSPARENCY", "ALT", "ATOMICSELECTION",
						 "AXIS", "BORDER", "BORDERCOLOR",
						 "CAPTION", "CELLPADDING", "CELLSPACING",  "CLEAR", "COLOR", 
						 "COLS", "COLSPAN", "COMPACT", "COORDS", "DISABLED", 
						 "FACE", "FONT", "HEADERS", "HEIGHT",
						 "HSPACE", "ID", "LENGTH",  "NAME", "NOHREF",
						 "NOSHADE", "NOWRAP", "REL", "REV", "ROWS", "ROWSPAN", "SCROLL", 
						 "SHAPE",  "SPAN", "START",  "TEXT",
						 "TITLE", "TYPE", "UNSELECTABLE", "VALIGN", "VALUE", "VSPACE",
						 "WIDTH", "WRAP"
					 };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string Escape(string html)
        {
            string output = html;
            switch (ConnectorSecurity.XSS){ 
                case ConnectorSecurity.SecutiryXSS.DHX_SECURITY_SAFEHTML:
                    output = CleanHtml(output);
                    break;
                case ConnectorSecurity.SecutiryXSS.DHX_SECURITY_SAFETEXT:
                    output = PurifyHtml(output);
                    break;              
                default:
                    break;
            }
            return output;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        internal static string CleanHtml(string html)
        {
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(_Prepare(html));
            return _Output(processNode(doc.DocumentNode).WriteTo());
        }
        internal static string PurifyHtml(string html)
        {
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(_Prepare(html));
            return _Output(doc.DocumentNode.InnerText);
        }
        private static string _Prepare(string before)
        {
            var after = before.Replace("&amp;", "&amp;amp;");
            after = before.Replace("&lt;", "&amp;lt;");
            after = before.Replace("&gt;", "&amp;gt;");
            after = Regex.Replace(after, @"/(&#*\w+?)[\x00-\x20]+?;/", "$1;", RegexOptions.Compiled);
            after = Regex.Replace(after, @"/(&#x*?)([0-9A-F]+);*?/", "$1$2;", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            after = HttpUtility.HtmlDecode(after);
            return after;
        }

        private static string _Output(string before)
        {
            return before;
        }
        private static HtmlNode processNode(HtmlNode node)
        {
            if (Array.BinarySearch(tagsWhitelist, node.Name) < 0)
            {
                node = node.OwnerDocument.CreateTextNode(string.Format("<![CDATA[{0}]]>", node.InnerText)); 
                return node;
            }

            ArrayList removeList = new ArrayList();
            foreach (HtmlAttribute att in node.Attributes)
            {
                if (Array.BinarySearch(attributesWhitelist, att.Name)  < 0)
                {
                    removeList.Add(att);
                }
            }

            foreach (HtmlAttribute att in removeList)
            {
                node.Attributes.Remove(att);
            }

            for (var i = 0; i < node.ChildNodes.Count; i++)
            {
                node.ChildNodes[i] = processNode(node.ChildNodes[i]);
            }
            return node;
           
        }


    }

    internal class CSRFSequrity
    {
        internal static void CSRFDetected()
        {
            #region LOG ENTRY
#if !NO_LOG
            var builder = new StringBuilder();
            var req = HttpContext.Current.Request;
            builder.Append("[SECURITY] Possible CSRF attack detected.\nReferer:");
            builder.Append(req.ServerVariables["HTTP_REFERER"]);
            builder.Append(";\n");
            builder.Append("Remote:");
            builder.Append(req.ServerVariables["REMOTE_ADDR"]);
            builder.Append(";\nRequest data\n");
            foreach (string i in req.Form.Keys)
            {
                builder.Append(string.Format("{0}:{1};\n", i, req.Form[i]));
            }
            builder.Append("\n\n");
            Log.WriteLine(new { }, builder.ToString());
#endif
            #endregion
            HttpContext.Current.Response.End();
        }

        internal static readonly string Var = "dhx_security";
   
        internal static void CheckCSRF(DataRequestType type){
            //var s = "dhx_security";
           
            if(type == DataRequestType.Edit){

                if (HttpContext.Current.Session == null || string.IsNullOrEmpty((string)HttpContext.Current.Session[CSRFSequrity.Var]))
                {
                    CSRFDetected();
                }

                var master = (string)HttpContext.Current.Session[CSRFSequrity.Var];
                var update = HttpContext.Current.Request[CSRFSequrity.Var];
                if( master != update){
                    CSRFDetected();
                }
            }
            else if(type == DataRequestType.Select){

                if (HttpContext.Current.Session != null && string.IsNullOrEmpty((string)HttpContext.Current.Session[CSRFSequrity.Var]))
                    HttpContext.Current.Session[CSRFSequrity.Var] = getMd5Hash(DateTime.Now.Ticks.ToString());
            }
        }
        static string getMd5Hash(string input)
        {
            System.Security.Cryptography.MD5 md5Hasher = System.Security.Cryptography.MD5.Create();
            byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(input));
            StringBuilder sBuilder = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }
            return sBuilder.ToString();
        }
   
    
    }

}

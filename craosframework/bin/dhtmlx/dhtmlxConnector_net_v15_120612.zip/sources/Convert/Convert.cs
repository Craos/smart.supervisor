﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Diagnostics;
using System.Web;
using System.Net;
using System.IO;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Supported convering modes
    /// </summary>
    public enum ConversionType{ 
        /// <summary>
        /// Convert to PDF
        /// </summary>
        PDF, 
        /// <summary>
        /// Convert To Excell
        /// </summary>
        Excell 
    };
    /// <summary>
    /// Provides convert functionality
    /// </summary>
    public class ConvertService
    {

        private string url;
        private ConversionType type;
        private string name;
        private bool inline;
        private dhtmlxGridConnector connector;

        /// <summary>
        /// creates instance of ConvertService class
        /// </summary>
        /// <param name="conn">connector</param>
        /// <param name="url">URI for conversion</param>
        public ConvertService(dhtmlxGridConnector conn, string url)
        {
            this.url = url;
            this.PDF();
            this.connector = conn;
            conn.End += new EventHandler<RenderEventArgs>(call_convert);
            //EventMaster::attach_static("connectorInit",array($this, "handle"));
        }



        /// <summary>
        /// applying settings for pdf conversion
        /// </summary>
        public void PDF()
        {
            this.PDF("data.pdf", false);
        }
        /// <summary>
        /// applying settings for pdf conversion
        /// </summary>
        /// <param name="name">output file name</param>
        public void PDF(string name)
        {
            this.PDF(name, false);
        }
        /// <summary>
        /// applying settings for pdf conversion
        /// </summary>
        /// <param name="name">output file name</param>
        /// <param name="inline">inline mode</param>
        public void PDF(string name, bool inline)
        {
            this.type = ConversionType.PDF;
            this.name = name;
            this.inline = inline;
        }



        /// <summary>
        /// applying settings for excell conversion
        /// </summary>
        public void Excel()
        {
             this.Excel("data.xls", false);      

        }
         /// <summary>
        /// applying settings for excell conversion
        /// </summary>
        /// <param name="name">output file name</param>      
        public void Excel(string name)
        {
            this.Excel(name, false);      

        }
        /// <summary>
        /// applying settings for excell conversion
        /// </summary>
        /// <param name="name">output file name</param>
        /// <param name="inline">inline mode</param>
        public void Excel(string name, bool inline)
        {
            this.type = ConversionType.Excell;
            this.name = name;
            this.inline = inline;

        }
        private void call_convert(object sender, RenderEventArgs e)
        {
            this.convert((sender as IdhtmlxConnector), (e.Writer as dhtmlxXMLWriter).Response, (e.Writer as dhtmlxXMLWriter));
        }
        
        /// <summary>
        /// set response headers for file output
        /// </summary>
        /// <param name="output">HttpResponse</param>
        /// <param name="size">size</param>
        /// <param name="name">name</param>
        /// <param name="inline">inline</param>
        private void as_file(HttpResponse output, string size, string name, bool inline)
        {
            output.AddHeader("Content-Type", "application/force-download");
            output.AddHeader("Content-Type", "application/octet-stream");
            output.AddHeader("Content-Type", "application/download");
            output.AddHeader("Content-Transfer-Encoding", "binary");
          
            output.AddHeader("Content-Length", size);
            if (inline)
                output.AddHeader("Content-Disposition", "inline; filename=" + name + ";");
            else
                output.AddHeader("Content-Disposition", "attachment; filename=" + name + ";");
        }
        /// <summary>
        /// converts grid data
        /// </summary>
        /// <param name="conn">IdhtmlxConnector</param>
        /// <param name="output">HttpResponse</param>
        /// <param name="_out">dhtmlxXMLWriter</param>
        public void convert(IdhtmlxConnector conn, HttpResponse output, dhtmlxXMLWriter _out)
        {

            try{
                if (this.type == ConversionType.PDF)
                    output.AddHeader("Content-type", "application/pdf");
                else
                    output.AddHeader("Content-type", "application/ms-excel");
               
      
               

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(this.url);
                //output.Output.NewLine = "\n";
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
               // request.Headers.Add("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
             //   request.Headers.Add("Accept-Encoding", "gzip, deflate");
             //   request.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
                var grid = _out.GetResult();
             
                grid = grid.Insert(6, "profile='color' ");
                grid = grid.Replace(grid.Substring(grid.IndexOf("<head>"), (grid.IndexOf("</head>") - grid.IndexOf("<head>") + 7)), (conn as dhtmlxGridConnector).Configuration.RenderForExport());
           
                string post_body = "grid_xml=";
            
                post_body += HttpUtility.UrlEncode(grid);
                byte[] ByteQuery = System.Text.Encoding.ASCII.GetBytes(post_body);
                request.ContentLength = ByteQuery.Length;
                Stream QueryStream = request.GetRequestStream();
                
                // Send the data.
                QueryStream.Write(ByteQuery, 0, ByteQuery.Length);
                QueryStream.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

               // Stream responseStream = response.GetResponseStream();
                int length = (int)response.ContentLength;
                _out.Reset();

                Stream receiveStream = response.GetResponseStream();
                
                byte[] buffer = new byte[32768];
                bool loop = true;
                while (loop == true)
                {
                    int read = receiveStream.Read(buffer, 0, buffer.Length);
                    if (read <= 0)
                        loop = false;
                    else
                        output.OutputStream.Write(buffer, 0, read);
                }

                // Releases the resources of the response.
                response.Close();
                
               as_file(output, length.ToString(), name, inline);
              
            }catch(Exception ex){
                _out.WriteRawString(ex.Message);
            }
           

        }

        
    }
}

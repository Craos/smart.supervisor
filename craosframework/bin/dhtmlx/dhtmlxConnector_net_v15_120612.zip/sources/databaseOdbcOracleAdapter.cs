﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;



namespace dhtmlxConnectors
{
    /// <summary>
    /// Oracle compatible implementation of idhtmlxDatabaseAdapter interface
    /// </summary>
    public class OdbcOracleAdapter : OdbcAdapter, IdhtmlxDatabaseAdapter
    {       

        /// <summary>
        /// Creates query to retrieve last inserted id
        /// </summary>
        /// <param name="TableName">Table name</param>      
        /// <param name="primary">Table primary key</param>
        /// <returns>SQL Select query</returns>
        protected override string CreateLastInsertedQuery(string TableName, Field primary)
        {
            string query = string.Format("SELECT {0} FROM (SELECT {0} FROM {1} ORDER BY ROWNUM DESC) WHERE ROWNUM=1", primary.InternalName, TableName);// SELECT SCOPE_IDENTITY();
            return query;
        }
        /// <summary>
        /// Creates SQL Insert query
        /// </summary>
        /// <param name="TableName">Table name to insert record into</param>
        /// <param name="ColumnValues">Values to insert</param>
        /// <returns>SQL Insert query</returns>
        protected override string CreateInsertQuery(string TableName, Dictionary<Field, string> ColumnValues)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, string.Format("Creating insert query from TableName: {0}, Fields-Values: {1}", TableName, Tools.Join(ColumnValues.Select(item => item.Key.ToString() + " = " + item.Value), ", ")));
#endif
            #endregion
            string insertQuery = "";

            insertQuery += string.Format("INSERT INTO {0} ({{0}}) VALUES ({{1}})", TableName);

            List<string> insertColumns = new List<string>();
            List<string> insertValues = new List<string>();

            foreach (Field insertField in ColumnValues.Keys)
            {
                insertColumns.Add(insertField.InternalName);
                insertValues.Add("'" + Tools.EscapeQueryValue(ColumnValues[insertField]) + "'");
            }
            string result = string.Format(insertQuery, string.Join(", ", insertColumns.ToArray()), string.Join(", ", insertValues.ToArray()));
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Insert query: " + result);
#endif
            #endregion
            return result;
        }
        /// <summary>
        /// Executes insert query
        /// </summary>
        /// <param name="TableName">Table name to insert record in</param>
        /// <param name="ColumnValues">Column values to insert</param>
        /// <param name="PrimaryKeyField">Primary Key column</param>
        /// <param name="PrimaryKeyValue">Primary key column value</param>
        /// <param name="AllFields">Collection of all tables fields</param>
        /// <returns>ID of inserted record</returns>
        public override object ExecuteInsertQuery(string TableName, Dictionary<Field, string> ColumnValues, Field PrimaryKeyField, object PrimaryKeyValue, dhtmlxFieldsCollection AllFields)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Entering: ExecuteInsertQuery");
#endif
            #endregion
            if (ColumnValues.Count == 0)
            {
                foreach (var field in AllFields)
                    if (field.InternalName != PrimaryKeyField.InternalName && field.InternalName != "*")
                    {
                        ColumnValues.Add(field, null);
                        break;
                    }
                if (ColumnValues.Count == 0)
                    throw new dhtmlxException("Data row cannot be inserted because there were no data specified");
            }
            try
            {

                var query = this.CreateInsertQuery(TableName, ColumnValues);

                this.ExecuteNonQuery(query);

                object result = this.ExecuteScalar(this.CreateLastInsertedQuery(TableName, PrimaryKeyField));
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Result: " + Convert.ToString(result));
#endif
                #endregion
                return result;
            }
            catch (SqlException ex)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Exception cought: " + ex.Message);
#endif
                #endregion
                throw new dhtmlxDBException("Insert operation failed with the following error: " + ex.Message);
            }
            catch (Exception ex)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Exception cought: " + ex.Message);
#endif
                #endregion
                throw new dhtmlxException("Insert operation failed with the following error: " + ex.Message);
            }
        }
        /// <summary>
        /// Creates T-SQL Select query based on parameters provided
        /// </summary>
        /// <param name="TableName">Table name to create query for</param>
        /// <param name="RequestedFields">Fields to include into result</param>
        /// <param name="Rules">Rules to apply to query</param>
        /// <param name="OrderBy">Order statements</param>
        /// <param name="StartIndex">Start index to take result rows from</param>
        /// <param name="Count">Number or rows to return</param>
        /// <param name="GroupBy">Group by fields</param>
        /// <param name="Having">Having statement</param>
        /// <returns>Ready-to-execute SQL query</returns>
        protected override string CreateSelectQuery(string TableName, IEnumerable<Field> RequestedFields, List<Rule> Rules, List<OrderByStatement> OrderBy, int StartIndex, int Count, string GroupBy, string Having)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, string.Format("Creating SelectQuery from TableName: {0}, Fields: {1}, Rules: {2}, OrderBy: {3}, StartIndex: {4}, Count: {5}", TableName, Tools.Join(RequestedFields, ", "), Tools.Join(Rules, " AND "), Tools.Join(OrderBy, ", "), StartIndex, Count));
#endif
            #endregion
            StringBuilder Query = new StringBuilder();
            string result = "";
            if (RequestedFields == null && Rules == null && OrderBy == null && StartIndex == -1 && Count == -1)
            {
                Query.Append(TableName);
                result = Query.ToString();
            }
            else
            {
                Query.Append("SELECT ");
                Query.Append(Tools.Join(RequestedFields.Select(a => a.ExternalName), ", "));
                Query.Append(" FROM ");

                Query.Append(" (SELECT dhx_table.*, ROWNUM rnum ");
                Query.Append(" FROM ");

                Query.Append(" ( SELECT ");
                Query.Append(Tools.Join(RequestedFields, ", "));
                Query.Append(" FROM ").Append(TableName);

                List<Rule> _rules = null;

                if (Rules != null)
                {
                    _rules = new List<Rule>();
                    _rules.AddRange(Rules);
                }

                if (_rules != null)
                {
                    string WhereClause = Tools.Join(_rules, " AND ");
                    if (!string.IsNullOrEmpty(WhereClause))
                        Query.Append(" WHERE ").Append(WhereClause);

                }

                if (GroupBy != null)
                {
                    Query.Append(" GROUP BY ").Append(GroupBy);
                }
                if (Having != null)
                {
                    Query.Append(" HAVING ").Append(Having);
                }

                if (OrderBy != null)
                {
                    string OrderByStatements = Tools.Join(OrderBy, ", ");
                    if (!string.IsNullOrEmpty(OrderByStatements))
                        Query.Append(" ORDER BY ").Append(OrderByStatements);

                }

                Query.Append(" ) ");

                Query.Append(" dhx_table ");
                if (Count > 0 && (Count != Int32.MaxValue || StartIndex > 0))
                {
                    Query.Append(string.Format(" WHERE ROWNUM <= {0} ", (Count + StartIndex).ToString()));
                }
                Query.Append(" ) ");

                if (Count > 0 && (Count != Int32.MaxValue || StartIndex > 0))
                {

                    Query.Append(string.Format(" WHERE  rnum > {0}", StartIndex.ToString()));
                }

                result = Query.ToString();

            }
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Select query: " + result);
#endif
            #endregion
            return result;
        }
    }
}
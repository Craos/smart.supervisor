﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Serves dhtmlxChart client requests
    /// </summary>
    public class dhtmlxChartConnector : dhtmlxDataViewConnector
    {
        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="TableName">Select query to use for data retrieval</param>
        /// <param name="Columns">Type of adapter to use for communication with database engine</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxChartConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base(TableName, Columns, PrimaryKeyColumnName, AdapterType, ConnectionString)
        {  }
        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString</param>
        public dhtmlxChartConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString)
        { }        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;
using System.Collections;
namespace dhtmlxConnectors
{
	/// <summary>
    /// Serves dhtmlxDataConnector client requests
    /// </summary>
    public class dhtmlxDataConnector : dhtmlxDataViewConnector
    {
        /// <summary>
        /// Creates new instance of dhtmlxDataConnector
        /// </summary>
        /// <param name="TableName">Select query to use for data retrieval</param>
        /// <param name="Columns">Type of adapter to use for communication with database engine</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxDataConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base(TableName, Columns, PrimaryKeyColumnName, AdapterType, ConnectionString)
        {
            this._Request = new DataRequestSDT(this, TableName, Columns, PrimaryKeyColumnName, "", AdapterType, ConnectionString);
            this._Request.EnableSingleRecordSelect = true;
        }

        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="items">Collection of data to be rendered</param>
        /// <param name="Properties">Comma separated properties to be rendered</param>
        /// <param name="IdPropertyName"></param>
        public dhtmlxDataConnector(IEnumerable items, string Properties, string IdPropertyName)
            :base(items, Properties, IdPropertyName)
        {
            this._Request = new DataRequestSDT(this, items, Properties, IdPropertyName, "");
            this._Request.EnableSingleRecordSelect = true;
        }



        /// <summary>
        /// Creates new instance of dhtmlxDataConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxDataConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString,  bool asIs)
            : base(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, asIs)
        {
            this._Request = new DataRequestSDT(this, SelectQuery, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs);
            this._Request.EnableSingleRecordSelect = true;
        }
        /// <summary>
        /// Creates new instance of dhtmlxDataConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxDataConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString )
            : this(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, false)
        {
            
        }
    }
}

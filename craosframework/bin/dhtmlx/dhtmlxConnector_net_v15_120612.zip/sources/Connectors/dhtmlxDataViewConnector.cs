﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;
using System.Web;
namespace dhtmlxConnectors
{   /// <summary>
    /// Serves dhtmlxDataView client requests
    /// </summary>
    public class dhtmlxDataViewConnector : dhtmlxConnector<dhtmlxDataViewDataItem>
    {
        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="TableName">Select query to use for data retrieval</param>
        /// <param name="Columns">Type of adapter to use for communication with database engine</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxDataViewConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base()
        {
            this._Request = new DataRequest(this, TableName, Columns, PrimaryKeyColumnName, "", AdapterType, ConnectionString);
           
        }

        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxDataViewConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, bool asIs)
            : base()
        {
            this._Request = new DataRequest(this, SelectQuery, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs);          
        }

        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="items">Collection of data to be rendered</param>
        /// <param name="Properties">Comma separated properties to be rendered</param>
        /// <param name="PrimaryKeyPropertyName"></param>
        public dhtmlxDataViewConnector(System.Collections.IEnumerable items, string Properties, string PrimaryKeyPropertyName)
        {
            this._Request = new DataRequest(this, items, Properties, PrimaryKeyPropertyName, "");
        }


        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxDataViewConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : this(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, false)
        {
           

        }

        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">XmlWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            xWriter.WriteStartElement("data");
            if (this.Request.StartIndex == 0)
                xWriter.WriteAttribute("total_count", TotalRowsCount.ToString());
            else
                xWriter.WriteAttribute("pos", this.Request.StartIndex.ToString());

            RenderSecurityKey(xWriter);

            RenderSections(xWriter);
        }

        /// <summary>
        /// Creates collection of dhtmlxDataViewDataItem objects from DataTable provided
        /// </summary>
        /// <param name="Rows">Table to create dhtmlxComboItem objects from</param>
        /// <returns>Collection of dhtmlxComboItem objects</returns>
        protected override List<dhtmlxDataViewDataItem> CreateDataItems(System.Data.DataTable Rows)
        {
            var items = new List<dhtmlxDataViewDataItem>();
            for (int i = 0; i < Rows.Rows.Count; i++)
            {
                var dataItem = new dhtmlxDataViewDataItem();
                if (this.Request.PrimaryKeyField != null)
                    dataItem.ID = Convert.ToString(Rows.Rows[i][this.Request.PrimaryKeyField.ExternalName]);

                for (var j = 0; j < Rows.Columns.Count; j++)
                {
                    if (!(this._Request.IdAppended && (Rows.Columns[j].ColumnName == this.Request.PrimaryKeyField.ExternalName)))
                        dataItem.DataFields.Add(Rows.Columns[j].ColumnName, Tools.ConvertToString(Rows.Rows[i][Rows.Columns[j]]));
                }
          //      foreach (DataColumn col in table.Columns)
          //          dataItem.DataFields.Add(col.ColumnName, Tools.ConvertToString(table.Rows[i][col]));
                dataItem.Index = i + this.Request.StartIndex;
                items.Add(dataItem);
            }

            return items;
           

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        protected override List<dhtmlxDataViewDataItem> _CreateDataItems(System.Collections.IEnumerable objects, Dictionary<string, System.Reflection.PropertyInfo> properties)
        {
            var items = new List<dhtmlxDataViewDataItem>();
            int i = 0;
            foreach( var item in objects)
            {
                var dataItem = new dhtmlxDataViewDataItem();
                if (this.Request.PrimaryKeyField != null && properties.ContainsKey(this.Request.PrimaryKeyField.InternalName))
                    dataItem.ID = Convert.ToString(properties[this.Request.PrimaryKeyField.InternalName].GetValue(item, null));

                foreach (var p in properties)
                {
                    if (!(this._Request.IdAppended && (p.Key == this.Request.PrimaryKeyField.ExternalName)))
                    {
                        
                        dataItem.DataFields.Add(p.Key, Tools.ConvertToString(p.Value.GetValue(item, null)));
                    }
                }
              
                dataItem.Index = i + this.Request.StartIndex;
                i++;
                items.Add(dataItem);
            }

            return items;
        }

    }
}

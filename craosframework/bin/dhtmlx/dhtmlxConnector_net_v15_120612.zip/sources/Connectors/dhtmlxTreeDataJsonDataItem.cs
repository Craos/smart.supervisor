﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Item of JsonDataTree
    /// </summary>
    public class dhtmlxTreeDataJsonDataItem : dhtmlxTreeDataDataItem
    {
        /// <summary>
        /// Outputs DataItem content to IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderEndContent(IdhtmlxWriter xWriter)
        {
            if (this.HasChildren)
            {
                xWriter.WriteRawString("\"data\":");
                (xWriter as dhtmlxJSONWriter).WriteStartArray();
            }
            foreach (dhtmlxTreeDataItem childItem in this.ChildNodes)
            {
                if (this.HasPrerender)
                    childItem.Prerender += delegate(object sender, EventArgs e) { this.CallPrerender(childItem, new ItemPrerenderEventArgs<dhtmlxTreeDataItem>(childItem)); };
                childItem.Render(xWriter);
            }
            if (this.HasChildren)
            {
                (xWriter as dhtmlxJSONWriter).WriteEndArray();
            }
            xWriter.WriteEndElement();
        }

  

    }
}

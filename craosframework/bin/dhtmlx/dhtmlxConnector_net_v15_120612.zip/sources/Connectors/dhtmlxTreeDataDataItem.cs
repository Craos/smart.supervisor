﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Node of dhtmlxDataTree
    /// </summary>
    public class dhtmlxTreeDataDataItem : dhtmlxTreeDataItem
    {

        /// <summary>
        /// Gets or Sets value indicating whether this item has child items (makes sense in case of EnableDynamicLoading mode enabled in connector)
        /// </summary>
        public override bool HasChildren
        {
            get
            {
                return GetAttribValue("dhx_kids") == "1";
            }
            set
            {
                SetAttribValue("dhx_kids", value ? "1" : "0");
            }
        }

        /// <summary>
        /// Outputs DataItem content to IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderStartContent(IdhtmlxWriter xWriter)
        {
            xWriter.WriteStartElement("item");
            xWriter.WriteAttribute("id", Convert.ToString(this.ID));
            foreach (KeyValuePair<string, string> pair in this.CustomAttribs)
                xWriter.WriteAttribute(pair.Key, pair.Value);
            if (this.Checked)
                xWriter.WriteAttribute("check", "1");
        }

        /// <summary>
        /// Outputs DataItem userData to IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderUserData(IdhtmlxWriter xWriter)
        {
            if (this.DataFields != null && this.DataFields.Count > 0)
            {
                foreach (KeyValuePair<string, string> pair in this.DataFields)
                {
                    xWriter.WriteAttribute(pair.Key, pair.Value);
                }
            }
            base.RenderUserData(xWriter);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Text.RegularExpressions;
using System.Data.Odbc;
using System.Collections;
namespace dhtmlxConnectors
{
    /// <summary>
    /// Serves dhtmlxConnector requests
    /// </summary>
    public class dhtmlxSchedulerConnector: dhtmlxConnector<dhtmlxSchedulerDataItem>
    {
        
        /// <summary>
        /// dictionary with predifined options,
        /// key - (string) Menu id
        /// values - option id, option value
        /// </summary>
        protected dhtmlxFieldOptionsCollection Options = new dhtmlxFieldOptionsCollection();
        /// <summary>
        /// dictionary with options connectors,
        /// key - menu id
        /// value - dhtmlxOptionsConnector
        /// </summary>
        protected Dictionary<Field, dhtmlxOptionsConnector> OptionsConnectors = new Dictionary<Field, dhtmlxOptionsConnector>();
        /// <summary>
        /// Gets or Sets field to take events' StartDate from
        /// </summary>
        public Field StartDateField
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or Sets field to take events' FinishDate from
        /// </summary>
        public Field FinishDateField
        {
            get;
            set;
        }

        private dhtmlxFieldsCollection _DetailsFields = new dhtmlxFieldsCollection();
        /// <summary>
        /// Gets or Sets reference to collection of details fields that describe event
        /// </summary>
        public dhtmlxFieldsCollection DetailsFields
        {
            get
            {
                return this._DetailsFields;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("DetailsFields");
                this._DetailsFields = value;
            }
        }

        /// <summary>
        /// Initializes own fields
        /// </summary>
        /// <param name="DetailsColumnNames">Comma-delimited list of columns that holds additional information about event to select and include into response (nullable)</param>
        /// <param name="StartDateColumnName">StartDate column name(nullable)</param>
        /// <param name="FinishDateColumnName">FinishDate column name(nullable)</param>
        protected void Initialize(string DetailsColumnNames, string StartDateColumnName, string FinishDateColumnName)
        {
            //details fields parse
            if (!string.IsNullOrEmpty(DetailsColumnNames))
                foreach (string fieldName in DetailsColumnNames.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    this.DetailsFields.Add(this.Request.Adapter.ParseField(fieldName));
            //start date
            if (!string.IsNullOrEmpty(StartDateColumnName))
                this.StartDateField = this.Request.Adapter.ParseField(StartDateColumnName);
            //finish date
            if (!string.IsNullOrEmpty(FinishDateColumnName))
                this.FinishDateField = this.Request.Adapter.ParseField(FinishDateColumnName);
            this.Request.BeforeSelect += new EventHandler(Request_BeforeSelect);
        }

        /// <summary>
        /// Modifies DataRequest.Select method to reflect Scheduler specific parameters
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="e">Event args</param>
        void Request_BeforeSelect(object sender, EventArgs e)
        {
            //include start date if it wasn't included yet
            if (!this.Request.RequestedFields.Contains(this.StartDateField))
                this.Request.RequestedFields.Add(this.StartDateField);
            //include finish date if it wasn't included yet
            if (!this.Request.RequestedFields.Contains(this.FinishDateField))
                this.Request.RequestedFields.Add(this.FinishDateField);
            //merge requested fields with details fields
            this.Request.RequestedFields = this.Request.RequestedFields.Union(this.DetailsFields).Distinct().ToFieldsCollection();

           
            if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["from"]) && this.FinishDateField != null)
                this.Request.Rules.Add(new FieldRule(this.FinishDateField, Operator.Greater, Convert.ToDateTime(HttpContext.Current.Request.QueryString["from"]).ToString(Tools.DateFormat)));

            if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["to"]) && this.StartDateField != null)
                this.Request.Rules.Add(new FieldRule(this.StartDateField, Operator.Lower, Convert.ToDateTime(HttpContext.Current.Request.QueryString["to"]).ToString(Tools.DateFormat)));
            
           }

        /// <summary>
        /// Creates new instance of dhtmlxSchedulerConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="StartDateColumnName">Field name to take events' start date from</param>
        /// <param name="FinishDateColumnName">Field name to take events' finish date from</param>
        /// <param name="DetailsColumnNames">Additional comma-delimited column names that describe event to select and include into response</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxSchedulerConnector(string SelectSource, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, string StartDateColumnName, string FinishDateColumnName, string DetailsColumnNames, bool asIs)
        {
            if (SelectSource.Trim().StartsWith("SELECT", StringComparison.InvariantCultureIgnoreCase))
                this._Request = new DataRequest(this, SelectSource, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs);
            else
                this._Request = new DataRequest(this, SelectSource,
                    string.Join(",", new string[] { PrimaryKeyColumnName, DetailsColumnNames, StartDateColumnName, FinishDateColumnName }.Where(col => !string.IsNullOrEmpty(col)).ToArray()),
                    PrimaryKeyColumnName, "", AdapterType, ConnectionString);
            ;
            this.Initialize(DetailsColumnNames, StartDateColumnName, FinishDateColumnName);
        }

        /// <summary>
        /// Creates new instance of dhtmlxSchedulerConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="StartDateColumnName">Field name to take events' start date from</param>
        /// <param name="FinishDateColumnName">Field name to take events' finish date from</param>
        /// <param name="DetailsColumnNames">Additional comma-delimited column names that describe event to select and include into response</param>
        public dhtmlxSchedulerConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString
            , string StartDateColumnName
            , string FinishDateColumnName
            , string DetailsColumnNames):this(SelectSource, PrimaryKeyColumnName, AdapterType, ConnectionString, StartDateColumnName, FinishDateColumnName, DetailsColumnNames, false)
        {
            
        }

        /// <summary>
        /// Creates new instance of dhtmlxSchedulerConnector
        /// </summary>
        /// <param name="Data">Data to be rendered</param>
        /// <param name="IdPropertyName">ID property name (nullable)</param>
        /// <param name="StartDatePropertyName">Property name to take events' start date from</param>
        /// <param name="FinishDatePropertyName">Property name to take events' finish date from</param>
        /// <param name="DetailsPropertyNames">Additional comma-delimited property names that describe event to select and include into response</param>
        public dhtmlxSchedulerConnector(
            IEnumerable Data
            , string IdPropertyName
            , string StartDatePropertyName
            , string FinishDatePropertyName
            , string DetailsPropertyNames)        
        {
            this._Request = new DataRequest(this, Data,
                   string.Join(",", new string[] { IdPropertyName, DetailsPropertyNames, StartDatePropertyName, FinishDatePropertyName }.Where(col => !string.IsNullOrEmpty(col)).ToArray()),
                   IdPropertyName, "");
            ;
            this.Initialize(DetailsPropertyNames, StartDatePropertyName, FinishDatePropertyName);
        }




        /// <summary>
        /// Creates new instance of dhtmlxSchedulerConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        /// <param name="StartDateColumnName">Field name to take events' start date from</param>
        /// <param name="FinishDateColumnName">Field name to take events' finish date from</param>
        /// <param name="DetailsColumnNames">Additional comma-delimited column names that describe event to select and include into response</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxSchedulerConnector(string SelectSource, string PrimaryKeyColumnName, IdhtmlxDatabaseAdapter Adapter, string StartDateColumnName, string FinishDateColumnName, string DetailsColumnNames, bool asIs)
        {
            if (SelectSource.Trim().StartsWith("SELECT", StringComparison.InvariantCultureIgnoreCase))
                this._Request = new DataRequest(this, SelectSource, PrimaryKeyColumnName, "", Adapter, asIs);
            else
                this._Request = new DataRequest(this, SelectSource,
                    string.Join(",", new string[] { PrimaryKeyColumnName, DetailsColumnNames, StartDateColumnName, FinishDateColumnName }.Where(col => !string.IsNullOrEmpty(col)).ToArray()),
                    PrimaryKeyColumnName, "", Adapter);
            ;
            this.Initialize(DetailsColumnNames, StartDateColumnName, FinishDateColumnName);
        }

        /// <summary>
        /// Creates new instance of dhtmlxSchedulerConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        /// <param name="StartDateColumnName">Field name to take events' start date from</param>
        /// <param name="FinishDateColumnName">Field name to take events' finish date from</param>
        /// <param name="DetailsColumnNames">Additional comma-delimited column names that describe event to select and include into response</param>
        public dhtmlxSchedulerConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , IdhtmlxDatabaseAdapter Adapter
            , string StartDateColumnName
            , string FinishDateColumnName
            , string DetailsColumnNames):this(SelectSource, PrimaryKeyColumnName, Adapter, StartDateColumnName, FinishDateColumnName, DetailsColumnNames, false)
        {
            
        }


        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">XmlWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter,  int TotalRowsCount)
        {
            xWriter.WriteStartElement("data");
            RenderSecurityKey(xWriter);
            RenderSections(xWriter);
        }

        /// <summary>
        /// Writes end tags of response header
        /// </summary>
        /// <param name="xWriter">XmlWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void EndRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            
            foreach (Field optionsField in this.OptionsConnectors.Keys)
            {
                    #region LOG ENTRY
                #if !NO_LOG
                Log.WriteLine(this, "Adding combo-options into response");
                #endif
                #endregion   
                var index = optionsField.InternalName;
                
                dhtmlxOptionsConnector currentConnector = this.OptionsConnectors[optionsField];
                currentConnector.ColumnIndex = index;
                currentConnector.Render(xWriter);             
            }
            foreach (Field optionsField in this.Options.Keys)
            {
                #region LOG ENTRY
                #if !NO_LOG
                    Log.WriteLine(this, "Adding explicit combo-options into response");
                #endif
                #endregion
                if (this.OptionsConnectors.ContainsKey(optionsField))
                    throw new dhtmlxException(optionsField.ExternalName + " column is contained both in OptionsConnectors and ExplicitOptions collections!");
                var index = optionsField.InternalName;
                dhtmlxOptionsConnector.RenderCustomCollection(xWriter, index, this.Options[optionsField]);
            }

            xWriter.WriteEndElement();
       
        }

        /// <summary>
        /// Gets field index by object
        /// </summary>
        /// <param name="field">Field to find index for</param>
        /// <returns>Field index or -1 if not found</returns>
        private int GetFieldIndex(Field field)
        {
            for (int i = 0; i < this.Request.RequestedFields.Count; i++)
                if (this.Request.RequestedFields[i].ExternalName == field.ExternalName)
                    return i;
            return -1;
        }

        /// <summary>
        /// Creates collection of dhtmlxSchedulerDataItem objects from DataTable provided
        /// </summary>
        /// <param name="Rows">Table to create dhtmlxSchedulerDataItem objects from</param>
        /// <returns>Collection of dhtmlxSchedulerDataItem objects</returns>
        protected override List<dhtmlxSchedulerDataItem> CreateDataItems(System.Data.DataTable Rows)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Converting DataRow object to connector specific data items");
#endif
            #endregion
            List<dhtmlxSchedulerDataItem> dataItems = new List<dhtmlxSchedulerDataItem>();
            for (int i = 0; i < Rows.Rows.Count; i++)
            {
                DataRow row = Rows.Rows[i];
                dhtmlxSchedulerDataItem dataItem = new dhtmlxSchedulerDataItem();
                if (this.Request.PrimaryKeyField != null)
                    dataItem.ID = Convert.ToString(row[this.Request.PrimaryKeyField.ExternalName]);
                
                string[] excludeColls = new string[]{
                    (this.Request.PrimaryKeyField == null ? "" : this.Request.PrimaryKeyField.ExternalName), 
                    (this.StartDateField == null ? "" : this.StartDateField.ExternalName), 
                    (this.FinishDateField == null ? "" : this.FinishDateField.ExternalName) 
                };
                foreach (DataColumn col in Rows.Columns.Cast<DataColumn>().Where(c => !excludeColls.Contains(c.ColumnName)))
                    dataItem.DataFields.Add(col.ColumnName, Tools.ConvertToString(row[col]));
                
                if (this.StartDateField != null)
                {
                    DateTime startDate;
                    if (DateTime.TryParse(Convert.ToString(row[this.StartDateField.ExternalName]), out startDate))
                        dataItem.StartDate = startDate;
                }
                if (this.FinishDateField != null)
                {
                    DateTime finishDate;
                    if (DateTime.TryParse(Convert.ToString(row[this.FinishDateField.ExternalName]), out finishDate))
                        dataItem.FinishDate = finishDate;
                }
                dataItem.Index = i;

                dataItems.Add(dataItem);
            }
            return dataItems;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="source"></param>
        /// <param name="parser"></param>
        /// <returns></returns>
        internal override Dictionary<string, System.Reflection.PropertyInfo> GetProperties(object source, ObjectParser parser)
        {
            
            return parser.GetProperties( source
                , this.Request.RequestedFields
                , this.Request.PrimaryKeyField
                , this.StartDateField
                , this.FinishDateField
                                
            );
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        protected override List<dhtmlxSchedulerDataItem> _CreateDataItems(System.Collections.IEnumerable objects, Dictionary<string, System.Reflection.PropertyInfo> properties)
        {
            List<dhtmlxSchedulerDataItem> dataItems = new List<dhtmlxSchedulerDataItem>();
            int i = 0;
            foreach(var item in objects)
            {
                dhtmlxSchedulerDataItem dataItem = new dhtmlxSchedulerDataItem();
                if (this.Request.PrimaryKeyField != null && properties.ContainsKey(this.Request.PrimaryKeyField.ExternalName))
                    dataItem.ID = Convert.ToString(properties[this.Request.PrimaryKeyField.ExternalName].GetValue(item, null));

                string[] excludeColls = new string[]{
                    (this.Request.PrimaryKeyField == null ? "" : this.Request.PrimaryKeyField.ExternalName), 
                    (this.StartDateField == null ? "" : this.StartDateField.ExternalName), 
                    (this.FinishDateField == null ? "" : this.FinishDateField.ExternalName) 
                };

                foreach (var p in properties)
                {
                    if (!excludeColls.Contains(p.Key))
                    {
                        dataItem.DataFields.Add(p.Key, Tools.ConvertToString(p.Value.GetValue(item, null)));
                    }
                }

                if (this.StartDateField != null && properties.ContainsKey(this.StartDateField.ExternalName))
                {
                    DateTime startDate;
                    if (DateTime.TryParse(Convert.ToString(properties[this.StartDateField.ExternalName].GetValue(item, null)), out startDate))
                        dataItem.StartDate = startDate;
                }
                if (this.FinishDateField != null && properties.ContainsKey(this.FinishDateField.ExternalName))
                {
                    DateTime finishDate;
                    if (DateTime.TryParse(Convert.ToString(properties[this.FinishDateField.ExternalName].GetValue(item, null)), out finishDate))
                        dataItem.FinishDate = finishDate;
                }
                dataItem.Index = i;

                dataItems.Add(dataItem);
            }
            return dataItems;
        }

        //TODO: Check how tree update works with default parent id = null

        /// <summary>
        /// Decodes field name to Field object
        /// </summary>
        /// <param name="EncodedField">Encoded field name token from QueryString</param>
        /// <returns>Field object that corresponds EncodedField, or null</returns>
        public override Field DecodeField(string EncodedField)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Encoding query field: " + EncodedField);
#endif
            #endregion
            string encField = EncodedField;// Regex.Replace(EncodedField, "^[^_]*.", "");
            switch(encField)
            {
                case "start_date":
                    return this.StartDateField;
                case "end_date":
                    return this.FinishDateField;
                case "id":
                    return this.Request.PrimaryKeyField;
                default:
                    if (this.DetailsFields.Contains(encField))
                        return this.DetailsFields[encField];
                    else
                        return null;
            }
        }
     /*   /// <summary>
        /// attaches options to scheduler
        /// </summary>
        /// <param name="name">options title</param>
        /// <param name="options">array of values</param>
        public void AddOptions(string name,  options)
        {
            if(Options == null)
                Options = new dhtmlxFieldOptionsCollection();


            Options.Add((TableField)name, options);
        }*/
        /// <summary>
        /// attaches options to scheduler
        /// </summary>
        /// <param name="name">options title</param>
        /// <param name="options">options connector</param>
        public void AddOptionsConnector(string name, dhtmlxOptionsConnector options)
        {
            if (OptionsConnectors == null)
                OptionsConnectors = new Dictionary<Field, dhtmlxOptionsConnector>();
            OptionsConnectors.Add((TableField)name, options);            
        }
    }
}

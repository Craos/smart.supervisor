﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Xml;
using System.Data;
using System.Web;
using dhtmlxConnectors;
namespace dhtmlxConnectors
{
    /// <summary>
    /// Serves dhtmlxCombo component requests
    /// </summary>
    public class dhtmlxComboConnector: dhtmlxConnector<dhtmlxComboItem>
    {
        /// <summary>
        /// Gets or Sets reference to Field object from where to take options Text property
        /// </summary>
        public Field ItemTextField
        {
            get;
            set;
        }

        /// <summary>
        /// Initilize properties
        /// </summary>
        /// <param name="Request">DataRequest object to use</param>
        /// <param name="ItemTextColumnName">Column name from where to take Text property of combo items</param>
        protected void Initialize(DataRequest Request, string ItemTextColumnName)
        {
            this._Request = Request;
            if (!string.IsNullOrEmpty(ItemTextColumnName))
                this.ItemTextField = this.Request.Adapter.ParseField(ItemTextColumnName);
            if (this.ItemTextField != null && this.Request.RequestedFields[this.ItemTextField.ExternalName] == null)
                this.Request.RequestedFields.Add(this.ItemTextField);
            this.Request.BeforeSelect += new EventHandler(Request_BeforeSelect);
        }

        /// <summary>
        /// Hook to modify select query by combo specific parameters token from QueryString
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Request_BeforeSelect(object sender, EventArgs e)
        {
            if (HttpContext.Current.Request.QueryString["pos"] != null)
                this.Request.StartIndex = Convert.ToInt32(HttpContext.Current.Request.QueryString["pos"]);
            if (HttpContext.Current.Request.QueryString["mask"] != null)
                this.Request.Rules.Add(new FieldRule(this.ItemTextField, Operator.Like, HttpContext.Current.Request.QueryString["mask"] + "%"));
            
        }
        /// <summary>
        /// Creates new instance of dhtmlxComboConnector using adapter type and connection string
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ItemTextColumnName">Column name to take option's Text property from</param>
        public dhtmlxComboConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString
            , string ItemTextColumnName
            )
            : this(SelectSource, PrimaryKeyColumnName, AdapterType, ConnectionString, ItemTextColumnName, false)
        {
            if (!string.IsNullOrEmpty(ItemTextColumnName))
                this.ItemTextField = this.Request.Adapter.ParseField(ItemTextColumnName);
            if (this.ItemTextField != null && this.Request.RequestedFields[this.ItemTextField.ExternalName] == null)
                this.Request.RequestedFields.Add(this.ItemTextField);
        }




        /// <summary>
        /// Creates new instance of dhtmlxComboConnector using adapter type and connection string
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ItemTextColumnName">Column name to take option's Text property from</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxComboConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString
            , string ItemTextColumnName
            , bool asIs)
        {
            if (SelectSource.Trim().StartsWith("SELECT", StringComparison.InvariantCultureIgnoreCase))
                this.Initialize(
                    new DataRequest(this, SelectSource, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs),
                    ItemTextColumnName
                    );
            else
                this.Initialize(
                new DataRequest(this, SelectSource, ItemTextColumnName, PrimaryKeyColumnName, "", AdapterType, ConnectionString),
                ItemTextColumnName
                );

        }

        /// <summary>
        /// Render collection of items
        /// </summary>
        /// <param name="items"></param>
        /// <param name="valuePropertyName"></param>
        /// <param name="textPropertyName"></param>
        public dhtmlxComboConnector(IEnumerable items, string valuePropertyName, string textPropertyName)
        {
            this._Request = new DataRequest(this, items, textPropertyName, valuePropertyName, "");
            this.ItemTextField = this.Request.Adapter.ParseField(valuePropertyName);
        }



        /// <summary>
        /// Creates new instance of dhtmlxComboConnector using ready-to-use database adapter
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        /// <param name="ItemTextColumnName">Column name to take option's Text property from</param>
        public dhtmlxComboConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , IdhtmlxDatabaseAdapter Adapter
            , string ItemTextColumnName
            ):this(SelectSource, PrimaryKeyColumnName, Adapter, ItemTextColumnName, false)
        {
            
        }


        /// <summary>
        /// Creates new instance of dhtmlxComboConnector using ready-to-use database adapter
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        /// <param name="ItemTextColumnName">Column name to take option's Text property from</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxComboConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , IdhtmlxDatabaseAdapter Adapter
            , string ItemTextColumnName
            , bool asIs)
        {
            if (SelectSource.Trim().StartsWith("SELECT", StringComparison.InvariantCultureIgnoreCase))
                this.Initialize(
                    new DataRequest(this, SelectSource, PrimaryKeyColumnName, "", Adapter, asIs),
                    ItemTextColumnName
                    );
            else
                this.Initialize(
                new DataRequest(this, SelectSource, ItemTextColumnName, PrimaryKeyColumnName, "", Adapter),
                ItemTextColumnName
                );
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="source"></param>
        /// <param name="parser"></param>
        /// <returns></returns>
        internal override Dictionary<string, System.Reflection.PropertyInfo> GetProperties(object source, ObjectParser parser)
        {
            return parser.GetProperties(source,
                this.Request.RequestedFields,
                    this.Request.PrimaryKeyField,
                    this.ItemTextField
                );        
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        protected override List<dhtmlxComboItem> _CreateDataItems(IEnumerable objects, Dictionary<string, System.Reflection.PropertyInfo> properties)
        {

            List<dhtmlxComboItem> dataItems = new List<dhtmlxComboItem>();
            if (properties == null)
            {
                return dataItems;
            }



            int i = 0;
            foreach (var item in objects)
            {
                //  DataRow row = Rows.Rows[i];
                dhtmlxComboItem dataItem = new dhtmlxComboItem();
                if (this.Request.PrimaryKeyField != null && properties.ContainsKey(this.Request.PrimaryKeyField.ExternalName))
                    dataItem.ID = Convert.ToString(properties[this.Request.PrimaryKeyField.ExternalName].GetValue(item, null));

                foreach (var p in properties)
                {
                    if (!(this._Request.IdAppended && (p.Key == this.Request.PrimaryKeyField.ExternalName)))
                        dataItem.DataFields.Add(p.Key, Tools.ConvertToString(p.Value.GetValue(item, null)));
                }

                if (this.ItemTextField != null && properties.ContainsKey(this.ItemTextField.ExternalName))
                    dataItem.Text = Convert.ToString(properties[this.ItemTextField.ExternalName].GetValue(item, null));
                dataItem.Index = i + this.Request.StartIndex;
                i++;
                dataItems.Add(dataItem);
            }
            return dataItems;
        }


        


        /// <summary>
        /// Creates collection of dhtmlxComboItem from DataTable provided
        /// </summary>
        /// <param name="Rows">DataTable to create items from</param>
        /// <returns>Collection of dhtmlxComboItem objects</returns>
        protected override List<dhtmlxComboItem> CreateDataItems(DataTable Rows)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Converting DataRow object to connector specific data items");
#endif
            #endregion
            List<dhtmlxComboItem> dataItems = new List<dhtmlxComboItem>();
            for (int i = 0; i < Rows.Rows.Count; i++)
            {
                DataRow row = Rows.Rows[i];
                dhtmlxComboItem dataItem = new dhtmlxComboItem();
                if (this.Request.PrimaryKeyField != null)
                    dataItem.ID = Convert.ToString(row[this.Request.PrimaryKeyField.ExternalName]);

                for (var j = 0; j < Rows.Columns.Count; j++)
                {
                    if (!(this._Request.IdAppended && (Rows.Columns[j].ColumnName == this.Request.PrimaryKeyField.ExternalName)))
                        dataItem.DataFields.Add(Rows.Columns[j].ColumnName, Tools.ConvertToString(row[Rows.Columns[j]]));
                }

                if (this.ItemTextField != null)
                    dataItem.Text = Convert.ToString(row[this.ItemTextField.ExternalName]);
                dataItem.Index = i + this.Request.StartIndex;
                dataItems.Add(dataItem);
            }
            return dataItems;
        }

        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">XmlWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            xWriter.WriteStartElement("complete");

            if (this.Request.StartIndex > 0)
                xWriter.WriteAttribute("add", "true");
            RenderSections(xWriter);
        }

    }
}

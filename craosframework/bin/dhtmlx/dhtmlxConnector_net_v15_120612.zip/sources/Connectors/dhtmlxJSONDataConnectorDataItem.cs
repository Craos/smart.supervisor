﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace dhtmlxConnectors
{ /// <summary>
    /// Represents dhtmlxJSONDataConnector data item
    /// </summary>
	public class dhtmlxJSONDataConnectorDataItem : dhtmlxDataItem
	{

        /// <summary>
        /// Outputs DataItem content to IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderStartContent(IdhtmlxWriter xWriter)
        {
             xWriter.WriteStartElement();

            foreach (string colName in this.DataFields.Keys)
            {
                xWriter.WriteField(colName, this.DataFields[colName]);
            }

        }
        
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{ 
    /// <summary>
    /// Represents dhtmlxDataView data item
    /// </summary>
    public class dhtmlxFormDataItem : dhtmlxDataItem
    {

        /// <summary>
        /// Outputs DataItem content to IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderStartContent(IdhtmlxWriter xWriter)
        {
            foreach (string colName in this.DataFields.Keys)
            {

                xWriter.WriteStartElement(colName);
                xWriter.WriteString(this.DataFields[colName]);
                xWriter.WriteEndElement();
            }
        }
    }
}

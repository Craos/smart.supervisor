﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
namespace dhtmlxConnectors
{
    /// <summary>
    /// Json Connector for dhtmlTouch Tree view
    /// </summary>
    public class dhtmlxTreeDataJsonConnector : dhtmlxTreeDataConnector
    {

    
        /// <summary>
        /// Creates new instance of dhtmlxTreeDataJsonConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Columns">Columns to be rendered</param>
        /// <param name="ParentIDColumnName">ForeignKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ExtraColumns">Columns to be included into select query, but ignored during render event</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxTreeDataJsonConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , string Columns
            , string ParentIDColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString
            , string ExtraColumns
            , bool asIs):base(SelectSource, PrimaryKeyColumnName, Columns, ParentIDColumnName, AdapterType, ConnectionString, ExtraColumns, asIs)
        {
        }

        /// <summary>
        /// Creates new instance of dhtmlxTreeDataJsonConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Columns">Columns to be rendered</param>
        /// <param name="ParentIDColumnName">ForeignKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxTreeDataJsonConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , string Columns
            , string ParentIDColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString) :
            base(SelectSource, PrimaryKeyColumnName, Columns, ParentIDColumnName, AdapterType, ConnectionString)
        {

        }
        /// <summary>
        /// Creates new instance of dhtmlxTreeDataJsonConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Columns">Columns to be rendered</param>
        /// <param name="ParentIDColumnName">ForeignKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ExtraColumns">Columns to be included into select query, but ignored during render event</param>
        public dhtmlxTreeDataJsonConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , string Columns
            , string ParentIDColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString
            , string ExtraColumns) :
            base(SelectSource, PrimaryKeyColumnName, Columns, ParentIDColumnName, AdapterType, ConnectionString, ExtraColumns)
        {

        }



        /// <summary>
        /// Initialize dhtmlxTreeDataJsonConnector from plain collection of objects
        /// </summary>
        /// <param name="items">Collection of tree items</param>
        /// <param name="IdProperty">Id property name</param>
        /// <param name="TextProperty">Name of the property to take node text</param>
        /// <param name="parentId">Property with id of parent item</param>
        public dhtmlxTreeDataJsonConnector(System.Collections.IEnumerable items, string IdProperty, string TextProperty, string parentId)
            :base(items, IdProperty, TextProperty, parentId)
        {
            
        }



        /// <summary>
        /// Returns new dhtmlxTreeDataItem object
        /// </summary>
        /// <returns></returns>
        protected override dhtmlxTreeDataItem _CreateDataItem()
        {
            return new dhtmlxTreeDataJsonDataItem();
        }

        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            if(!string.IsNullOrEmpty(this.Request.RelationIDValue)){
                xWriter.WriteStartElement("data");
                xWriter.WriteAttribute("parent", this.RootItemRelationIDValue == this.Request.RelationIDValue ? "0" : this.Request.RelationIDValue);
                RenderSecurityKey(xWriter);
                RenderSections(xWriter);
 
                xWriter.WriteRawString("\"data\":");
            }
            (xWriter as dhtmlxJSONWriter).WriteStartArray();
            
            
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderSections(IdhtmlxWriter xWriter)
        {
            var sections = new string[this.Sections.Count];
            int i=0;
           
            foreach (var sec in this.Sections)
            {
                sections[i++] = string.Format(", \"{0}\":{1}", sec.Key, sec.Value);
                
            }
            xWriter.WriteRawString(string.Join(",", sections));
        }

        /// <summary>
        /// Writes end tags of response header
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void EndRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            (xWriter as dhtmlxJSONWriter).WriteEndArray();
            if (!string.IsNullOrEmpty(this.Request.RelationIDValue))
            {
                xWriter.WriteEndElement();
            }
        }
     
        /// <summary>
        /// Renders processing results into current response
        /// </summary>
        /// <param name="response">HttpResponse object where to put results to</param>
        public override void RenderResponse(HttpResponse response)
        {
            response.Output.NewLine = "\n";
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering response");
#endif
            #endregion
            this.RenderResponseHeader(response);
            StringBuilder sb = new StringBuilder();
            var xWriter = new dhtmlxJSONWriter(sb);
            this.Render(xWriter);

            response.Write(xWriter.GetResult());

        }

        /// <summary>
        /// Renders and prepares xml specific headers
        /// </summary>
        /// <param name="response">HttpResponse object to use</param>
        protected override void RenderResponseHeader(HttpResponse response)
        {
            response.ContentType = "application/json";

        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Serves dhtmlGrid client requests
    /// </summary>
    public class dhtmlxGridConnector : dhtmlxGridConnectorBase<dhtmlxGridDataItem>
    {
        /// <summary>
        /// dhtmlxGridConfiguration instance
        /// </summary>
        protected dhtmlxGridConfiguration Config = null;
        /// <summary>
        /// dhtmlxGridConfiguration instance
        /// </summary>
        public dhtmlxGridConfiguration Configuration
        {
            get { return Config; }
        }
        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ExtraColumnNames">Columns to be included into select query, but ignored during render event</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxGridConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, string ExtraColumnNames, bool asIs)
            : base()
        {
            this._Request = new DataRequest(this, SelectQuery, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs);
            this.ParseExtraColumns(ExtraColumnNames);
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxGridConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, bool asIs)
            : this(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, "", asIs)
        {
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxGridConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : this(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, false)
        {
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="TableName">Table name to run query against</param>
        /// <param name="Columns">Columns to select</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ExtraColumnNames">Columns to be included into select query, but ignored during render event</param>
        public dhtmlxGridConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, string ExtraColumnNames)
            : base()
        {
            this._Request = new DataRequest(this, TableName, Columns, PrimaryKeyColumnName, "", AdapterType, ConnectionString);
            this.ParseExtraColumns(ExtraColumnNames);
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="TableName">Table name to run query against</param>
        /// <param name="Columns">Columns to select</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxGridConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : this(TableName, Columns, PrimaryKeyColumnName, AdapterType, ConnectionString, "")
        {
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        /// <param name="ExtraColumnNames">Columns to be included into select query, but ignored during render event</param>
        public dhtmlxGridConnector(string SelectQuery, string PrimaryKeyColumnName, IdhtmlxDatabaseAdapter Adapter, string ExtraColumnNames)
            : base()
        {
            this._Request = new DataRequest(this, SelectQuery, PrimaryKeyColumnName, "", Adapter);
            this.ParseExtraColumns(ExtraColumnNames);
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        public dhtmlxGridConnector(string SelectQuery, string PrimaryKeyColumnName, IdhtmlxDatabaseAdapter Adapter)
            : this(SelectQuery, PrimaryKeyColumnName, Adapter, "")
        {
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="TableName">Table name to run query against</param>
        /// <param name="Columns">Columns to select</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        /// <param name="ExtraColumnNames">Columns to be included into select query, but ignored during render event</param>
        public dhtmlxGridConnector(string TableName, string Columns, string PrimaryKeyColumnName, IdhtmlxDatabaseAdapter Adapter, string ExtraColumnNames)
            : base()
        {
            this._Request = new DataRequest(this, TableName, Columns, PrimaryKeyColumnName, "", Adapter);
            this.ParseExtraColumns(ExtraColumnNames);
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="TableName">Table name to run query against</param>
        /// <param name="Columns">Columns to select</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        public dhtmlxGridConnector(string TableName, string Columns, string PrimaryKeyColumnName, IdhtmlxDatabaseAdapter Adapter)
            : this(TableName, Columns, PrimaryKeyColumnName, Adapter, "")
        { 
        }

        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="Data">Items collection</param>
        /// <param name="Properties">Properties to render</param>
        /// <param name="IdPropertyName">PrimaryKey property name (nullable)</param>
        public dhtmlxGridConnector(System.Collections.IEnumerable Data, string Properties, string IdPropertyName)
            :this(Data, Properties, IdPropertyName, "")
        {
        }
        /// <summary>
        /// Creates new instance of dhtmlxGridConnector
        /// </summary>
        /// <param name="Data">Items collection</param>
        /// <param name="Properties">Properties to render</param>
        /// <param name="IdPropertyName">PrimaryKey property name (nullable)</param>
        /// <param name="ExtraProperyNames">Properties to be included into DataItems, but ignored during render event</param>
        public dhtmlxGridConnector(System.Collections.IEnumerable Data, string Properties, string IdPropertyName, string ExtraProperyNames)
        {
            this._Request = new DataRequest(this, Data, Properties, IdPropertyName, "");
            this.ParseExtraColumns(ExtraProperyNames);
        }

        /// <summary>
        /// Attaching config object to grid
        /// </summary>
        /// <param name="config">dhtmlxGridConfiguration instance</param>

        public void SetConfig(dhtmlxGridConfiguration config)
        {
            Config = config;
        }


        
        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">XmlWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter,  int TotalRowsCount)
        {
            xWriter.WriteStartElement("rows");
            if (this.Request.StartIndex == 0)
                xWriter.WriteAttribute("total_count", TotalRowsCount.ToString());
            else
                xWriter.WriteAttribute("pos", this.Request.StartIndex.ToString());
            RenderSecurityKey(xWriter);
            if (Config != null)
                Config.RenderHeader(xWriter);

            RenderSections(xWriter);
        }

        /// <summary>
        /// Creates collection of dhtmlxGridDataItem from DataTable provided
        /// </summary>
        /// <param name="Rows">DataTable to create items from</param>
        /// <returns>Collection of dhtmlxGridDataItem objects</returns>
        protected override List<dhtmlxGridDataItem> CreateDataItems(DataTable Rows)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Converting DataRow object to connector specific data items");
#endif
            #endregion
            List<dhtmlxGridDataItem> dataItems = new List<dhtmlxGridDataItem>();
            List<string> ExtraColumnNames = this.ExtraFields.Select(eField => eField.ExternalName).ToList();
            for (int i = 0; i < Rows.Rows.Count; i++)
            {
                DataRow row = Rows.Rows[i];
                dhtmlxGridDataItem dataItem = new dhtmlxGridDataItem();
                if (this.Request.PrimaryKeyField != null)
                    dataItem.ID = Convert.ToString(row[this.Request.PrimaryKeyField.ExternalName]);


                for(var j = 0; j < Rows.Columns.Count; j++){
                    if (!(this._Request.IdAppended && (Rows.Columns[j].ColumnName == this.Request.PrimaryKeyField.ExternalName)))
                        dataItem.DataFields.Add(Rows.Columns[j].ColumnName, Tools.ConvertToString(row[Rows.Columns[j]]));
                }
                dataItem.Index = i + this.Request.StartIndex;
                dataItem.SetExtraColumns(ExtraColumnNames);
                dataItems.Add(dataItem);
            }
            return dataItems;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        protected override List<dhtmlxGridDataItem> _CreateDataItems(System.Collections.IEnumerable objects, Dictionary<string, System.Reflection.PropertyInfo> properties)
        {

            var items = new List<dhtmlxGridDataItem>();
            int i = 0;
            List<string> ExtraColumnNames = this.ExtraFields.Select(eField => eField.ExternalName).ToList();
            foreach (var item in objects)
            {
                var dataItem = new dhtmlxGridDataItem();
                if (this.Request.PrimaryKeyField != null && properties.ContainsKey(this.Request.PrimaryKeyField.InternalName))
                    dataItem.ID = Convert.ToString(properties[this.Request.PrimaryKeyField.InternalName].GetValue(item, null));

                foreach (var p in properties)
                {
                    if (!(this._Request.IdAppended && (p.Key == this.Request.PrimaryKeyField.ExternalName)))
                    {

                        dataItem.DataFields.Add(p.Key, Tools.ConvertToString(p.Value.GetValue(item, null)));
                    }
                }

                dataItem.Index = i + this.Request.StartIndex;
                dataItem.SetExtraColumns(ExtraColumnNames);
                i++;
                items.Add(dataItem);
            }

            return items;
        }
        //protected void ParseRequest()

        
    }
}

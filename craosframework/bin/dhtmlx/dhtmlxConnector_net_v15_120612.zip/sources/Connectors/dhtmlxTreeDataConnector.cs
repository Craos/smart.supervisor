﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
namespace dhtmlxConnectors
{
    /// <summary>
    /// Connector for dhtmlTouch Tree view
    /// </summary>
    public class dhtmlxTreeDataConnector : dhtmlxTreeConnector
    {


        /// <summary>
        /// Creates new instance of dhtmlxTreeConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Columns">Columns to be rendered</param>
        /// <param name="ParentIDColumnName">ForeignKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ExtraColumns">Columns to be included into select query, but ignored during render event</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxTreeDataConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , string Columns
            , string ParentIDColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString            
            , string ExtraColumns
            ,  bool asIs)
        {
            if (SelectSource.Trim().StartsWith("SELECT", StringComparison.InvariantCultureIgnoreCase))
                this._Request = new DataRequestSDT(this, SelectSource, PrimaryKeyColumnName, ParentIDColumnName, AdapterType, ConnectionString, asIs);//sql
            else
                this._Request = new DataRequestSDT(this, SelectSource, "", PrimaryKeyColumnName, ParentIDColumnName, AdapterType, ConnectionString);//table
            this.Request.InitializeColumns(Columns);
            Initialize("");
            ParseExtraColumns(ExtraColumns);
        }

        /// <summary>
        /// Creates new instance of dhtmlxTreeConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Columns">Columns to be rendered</param>
        /// <param name="ParentIDColumnName">ForeignKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxTreeDataConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , string Columns
            , string ParentIDColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString) :
            this(SelectSource, PrimaryKeyColumnName,Columns,  ParentIDColumnName, AdapterType, ConnectionString, "",false)
        {

        }
        /// <summary>
        /// Creates new instance of dhtmlxTreeConnector
        /// </summary>
        /// <param name="SelectSource">Select query or Table name to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="Columns">Columns to be rendered</param>
        /// <param name="ParentIDColumnName">ForeignKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="ExtraFields">Columns to be included into select query, but ignored during render event</param>
        public dhtmlxTreeDataConnector(
            string SelectSource
            , string PrimaryKeyColumnName
            , string Columns
            , string ParentIDColumnName
            , dhtmlxDatabaseAdapterType AdapterType
            , string ConnectionString
            , string ExtraFields) :
            this(SelectSource, PrimaryKeyColumnName, Columns, ParentIDColumnName, AdapterType, ConnectionString, ExtraFields, false)
        {

        }



        /// <summary>
        /// Initialize tree connector from plain collection of objects
        /// </summary>
        /// <param name="items">Collection of tree items</param>
        /// <param name="IdProperty">Id property name</param>
        /// <param name="TextProperty">Name of the property to take node text</param>
        /// <param name="parentId">Property with id of parent item</param>
        public dhtmlxTreeDataConnector(System.Collections.IEnumerable items, string IdProperty, string TextProperty, string parentId)
        {
            this._Request = new DataRequestSDT(this, items, TextProperty, IdProperty, parentId);
            Initialize(TextProperty);
           
        }

       

        

    
        /// <summary>
        /// Returns new dhtmlxTreeDataItem object
        /// </summary>
        /// <returns></returns>
        protected override dhtmlxTreeDataItem _CreateDataItem()
        {
            return new dhtmlxTreeDataDataItem();
        }



        /// <summary>
        /// Renders results of data actions into XmlWriter provided
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render response to</param>
        /// <param name="ResultsToRender">Collection of DataAction object to render</param>
        public override void RenderActions(IdhtmlxWriter xWriter, IEnumerable<DataAction> ResultsToRender)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering data actions: [" + Tools.Join(ResultsToRender, ", ") + "]");
#endif
            #endregion
            var is_xml = false;
            foreach (DataAction actionResult in ResultsToRender)
            {
                if (actionResult.ActionProtocol == ActionProtocol.Standart)
                {
                    is_xml = true;
                    break;
                }
            }

            var xml = new dhtmlxXMLWriter(new StringBuilder(), null);

            if (is_xml)
            {
                var req = HttpContext.Current.Response;
                req.ContentType = "text/xml";
                req.Write("<?xml version=\"1.0\" encoding=\"" + req.HeaderEncoding.BodyName + "\"?>");
                xml.WriteStartElement("data");

            }

            if (this.HasBeforeOutputHandler)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling BeforeOutput event");
#endif
                #endregion
                this.FireBeforeOutputEvent(this, new RenderEventArgs(xWriter));
            }


            foreach (DataAction actionResult in ResultsToRender)
            {
                if (actionResult.ActionProtocol == ActionProtocol.SDT)
                {
                    if (actionResult.ActionType == ActionType.Error)
                        xWriter.WriteRawString("false");
                    else
                        xWriter.WriteRawString("true");
                    if (actionResult.ActionType == ActionType.Inserted)
                        xWriter.WriteRawString('\n' + Convert.ToString(actionResult.PostoperationalPrimaryKeyValue));
                }
                else
                {

                    xml.WriteStartElement("action");

                    xml.WriteAttribute("type", actionResult.ActionType == ActionType.Custom ? actionResult.CustomActionName : this.Request.ConvertActionType(actionResult.ActionType));
                    xml.WriteAttribute("sid", Convert.ToString(actionResult.PrimaryKeyValue));
                    xml.WriteAttribute("tid", Convert.ToString(actionResult.PostoperationalPrimaryKeyValue));
                    foreach (KeyValuePair<string, string> attrib in actionResult.CustomAttribs)
                        xml.WriteAttribute(attrib.Key, attrib.Value);
                    if (!string.IsNullOrEmpty(actionResult.Details))
                        xml.WriteString(actionResult.Details);

                    xml.WriteEndElement();

                }
            }
            if (is_xml)
            {
                xml.WriteEndElement();
                xWriter.WriteRawString(xml.GetResult());
            }


            if (this.HasEndHandler)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling End event");
#endif
                #endregion
                this.FireEndEvent(this, new RenderEventArgs(xWriter));
            }
        }



        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">XmlWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            xWriter.WriteStartElement("data");
            if (!string.IsNullOrEmpty(this.Request.RelationIDValue))
            {
                xWriter.WriteAttribute("parent", this.RootItemRelationIDValue == this.Request.RelationIDValue ? "0" : this.Request.RelationIDValue);
            }
            RenderSecurityKey(xWriter);
            RenderSections(xWriter);
        }
    }
}

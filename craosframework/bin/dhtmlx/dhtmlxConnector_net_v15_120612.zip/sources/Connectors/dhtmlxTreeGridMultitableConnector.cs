﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
namespace dhtmlxConnectors
{
    /// <summary>
    /// TreeGrid connector, which uses different tables for different levels of item hieararchy
    /// </summary>
    public class dhtmlxTreeGridMultitableConnector : dhtmlxTreeGridConnector
    {
        /// <summary>
        /// Current level
        /// </summary>
        public int Level{get; protected set;}
        /// <summary>
        /// Max level
        /// </summary>
        public int MaxLevel { get; set; }

        private dhtmlxDatabaseAdapterType ad_type;
        private string connectionString;
        private IdhtmlxDatabaseAdapter adapter = null;

        private void attachEvents()
        {
            this.BeforeProcessing += new EventHandler<DataActionProcessingEventArgs>(this.idTranslateBefore);
            this.AfterProcessing += new EventHandler<DataActionProcessingEventArgs>(this.idTranslateAfter);
            this.RequestHasChildren += new EventHandler<RequestChildrenEventArgs<dhtmlxTreeGridDataItem>>(this.hasChildren);
            this.BeforeRender += new EventHandler<ItemPrerenderEventArgs<dhtmlxTreeGridDataItem>>(this.outIds);
            this.BeforeOutput += new EventHandler<RenderEventArgs>(this.beforeOut);
             this.AfterSelect += new EventHandler<DataSelectedEventArgs>(this.rulesIds);
        }

        /// <summary>
        /// Creates new instance of dhtmlxTreeGridMultitableConnector
        /// </summary>    
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxTreeGridMultitableConnector(dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
        {
           
            
            this.ad_type = AdapterType;
            this.connectionString = ConnectionString;
        }


        /// <summary>
        /// Creates new instance of dhtmlxTreeGridMultitableConnector
        /// </summary>   
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        public dhtmlxTreeGridMultitableConnector(IdhtmlxDatabaseAdapter Adapter)
        {
            
            
            adapter = Adapter;
        }

 

        /// <summary>
        /// Parse multitable item id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="setLevel"></param>
        /// <returns></returns>
        public string ParseId(string id, bool setLevel){
            string[] del = new string[2];
            del[0] = "#";
            del[1] = "%23";

            var parsed = id.Split(del,StringSplitOptions.None );
            if (parsed.Length == 1)
                return parsed[0];
		    
		    if (setLevel) {
                this.Level = int.Parse(parsed[0])+1;
		    }
          

            var res = (parsed[1]);
            
            return res;
        }
        /// <summary>
        /// Parse mulititable item id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string ParseId(string id)
        {
            return ParseId(id, true);
        }

        /// <summary>
        /// Get current request level
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public int GetLevel(HttpRequest context)
        {

            if (context.QueryString["id"] == null)
            {
                if (context.Form["ids"] != null)
                {
                    var ids = context.Form["ids"].Split(',');
                    var id = ids[0];
                    ParseId(id);
                    this.Level--;
                }
            } else {
                var id = this.ParseId(context.QueryString["id"]);
                ParseId(id);
            }
            


            return this.Level;
            
        }


        /// <summary>
        /// remove level prefix from id, parent id and set new id before processing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="action"></param>
        protected void idTranslateBefore(object sender, DataActionProcessingEventArgs action){
            
            this.Request.RelationIDValue = null;
            var id = this.ParseId(action.DataAction.PrimaryKeyValue.ToString());
            action.DataAction.PrimaryKeyValue = id;
            action.DataAction.UserData.Add("gr_id", id.ToString());
            
            action.DataAction.PostoperationalPrimaryKeyValue = id;
            if (action.DataAction.UserData.ContainsKey("gr_pid"))
            {
                var pid = action.DataAction.UserData["gr_pid"];
                pid = this.ParseId(pid, false);
                action.DataAction.UserData["gr_pid"] = pid;
            }

        }
	   
        /// <summary>
        /// Add level prefix in id and new id after processing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="action"></param>
	    protected void  idTranslateAfter(object sender, DataActionProcessingEventArgs action) {
            this.Level--;
            var id = action.DataAction.PrimaryKeyValue;
		    action.DataAction.PrimaryKeyValue = this.Level.ToString() + "%23" + id.ToString();
		    id = action.DataAction.PostoperationalPrimaryKeyValue;
            action.DataAction.PostoperationalPrimaryKeyValue = this.Level.ToString() + "%23" + id.ToString();
        }
        /// <summary>
        /// Add level prefix in id and new id after processing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="action"></param>
        protected void outIds(object sender, ItemPrerenderEventArgs<dhtmlxTreeGridDataItem> action)
        {
            action.DataItem.ID = this.Level + "%23" + action.DataItem.ID;
           
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void beforeOut(object sender, EventArgs e)
        {
            if (this.Request.RootItemRelationIDValue != this.Request.RelationIDValue)
            {
                this.Request.RelationIDValue = this.ParseId(this.Request.RelationIDValue);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rulesIds(object sender, EventArgs e)
        {
            if (this.Request.RootItemRelationIDValue != this.Request.RelationIDValue)
            {
                this.Request.RelationIDValue = (Level - 1).ToString() + "%23" + this.Request.RelationIDValue;
            }
        }
        
        /// <summary>
        /// Add level prefix in id and new id after processing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="action"></param>
        protected void hasChildren(object sender, RequestChildrenEventArgs<dhtmlxTreeGridDataItem> action)
        {
            if (this.MaxLevel != default(int) && this.Level == this.MaxLevel)
                action.HasChildren = false;
            else
                action.HasChildren = true;
        }



        /// <summary>
        /// Processes client commands token from QueryString and Form collections
        /// </summary>
        /// <param name="QueryString">QueryString collection of client request</param>
        /// <param name="Form">Form collection of client request</param>
        public override void ProcessRequest(NameValueCollection QueryString, NameValueCollection Form)
        {

            var query = new NameValueCollection(QueryString);
            var form = new NameValueCollection(Form);
            if (query["id"] != null)
            {

                var id = this.ParseId(query["id"]);
                query["id"] = id;

            }

            base.ProcessRequest(query, form);

        }

        /// <summary>
        /// Process sql query
        /// </summary>
        /// <param name="SelectQuery"></param>
        /// <param name="PrimaryKeyColumnName"></param>
        /// <param name="ParentIDColumnName"></param>
        /// <param name="ExtraColumnNames"></param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public void RenderQuery(string SelectQuery, string PrimaryKeyColumnName, string ParentIDColumnName, string ExtraColumnNames, bool asIs){
            
            if(this.adapter != null){
                this._Request = new DataRequest(this, SelectQuery, PrimaryKeyColumnName, ParentIDColumnName, adapter, asIs);
            }else{
                this._Request = new DataRequest(this, SelectQuery, PrimaryKeyColumnName, ParentIDColumnName, ad_type, connectionString, asIs);

            }
            this.ParseExtraColumns(ExtraColumnNames);
            this.EnableDynamicLoading = true;
            attachEvents();

        }
        /// <summary>
        /// Process sql query
        /// </summary>
        /// <param name="SelectQuery"></param>
        /// <param name="PrimaryKeyColumnName"></param>
        /// <param name="ParentIDColumnName"></param>
        /// <param name="ExtraColumnNames"></param>
        public void RenderQuery(string SelectQuery, string PrimaryKeyColumnName, string ParentIDColumnName, string ExtraColumnNames)
        {

            this.RenderQuery(SelectQuery, PrimaryKeyColumnName, ParentIDColumnName, ExtraColumnNames, false);

        }




        /// <summary>
        /// Process sql query
        /// </summary>
        /// <param name="SelectQuery"></param>
        /// <param name="PrimaryKeyColumnName"></param>
        /// <param name="ParentIDColumnName"></param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public void RenderQuery(string SelectQuery, string PrimaryKeyColumnName, string ParentIDColumnName, bool asIs)           
        {
            this.RenderQuery(SelectQuery, PrimaryKeyColumnName, ParentIDColumnName, "", asIs);

        }

        /// <summary>
        /// Process sql query
        /// </summary>
        /// <param name="SelectQuery"></param>
        /// <param name="PrimaryKeyColumnName"></param>
        /// <param name="ParentIDColumnName"></param>
        public void RenderQuery(string SelectQuery, string PrimaryKeyColumnName, string ParentIDColumnName)
        {
            this.RenderQuery(SelectQuery, PrimaryKeyColumnName, ParentIDColumnName, "", false);

        }

        /// <summary>
        /// Process table
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="Columns"></param>
        /// <param name="PrimaryKeyColumnName"></param>
        /// <param name="ParentIDColumnName"></param>
        /// <param name="ExtraColumnNames"></param>
        public void RenderTable(string TableName, string Columns, string PrimaryKeyColumnName, string ParentIDColumnName, string ExtraColumnNames){
            if(this.adapter != null){
                this._Request = new DataRequest(this, TableName, Columns, PrimaryKeyColumnName, ParentIDColumnName, adapter);
            }else{
                this._Request = new DataRequest(this, TableName, Columns, PrimaryKeyColumnName, ParentIDColumnName, ad_type, connectionString);
            }
            this.ParseExtraColumns(ExtraColumnNames);
            this.EnableDynamicLoading = true;
            attachEvents();
            
        }
        /// <summary>
        /// Process table
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="Columns"></param>
        /// <param name="PrimaryKeyColumnName"></param>
        /// <param name="ParentIDColumnName"></param>
        public void RenderTable(string TableName, string Columns, string PrimaryKeyColumnName, string ParentIDColumnName)
        {
             RenderTable(TableName, Columns, PrimaryKeyColumnName, ParentIDColumnName, "");
        }
        
  }
}

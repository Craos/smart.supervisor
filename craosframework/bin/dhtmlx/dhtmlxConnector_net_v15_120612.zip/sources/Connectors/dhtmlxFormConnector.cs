﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;


namespace dhtmlxConnectors
{
    /// <summary>
    /// Serves dhtmlxForm client requests
    /// </summary>
    public class dhtmlxFormConnector : dhtmlxConnector<dhtmlxFormDataItem>
    {
        /// <summary>
        /// Creates new instance of dhtmlxFormConnector
        /// </summary>
        /// <param name="TableName">Select query to use for data retrieval</param>
        /// <param name="Columns">Type of adapter to use for communication with database engine</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxFormConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base()
        {
            this._Request = new DataRequest(this, TableName, Columns, PrimaryKeyColumnName, "", AdapterType, ConnectionString);
            this._Request.EnableSingleRecordSelect = true;
        }

        /// <summary>
        /// Creates new instance of dhtmlxFormConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxFormConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, bool asIs)
            : base()
        {
            this._Request = new DataRequest(this, SelectQuery, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs);
            this._Request.EnableSingleRecordSelect = true;
           
        }

        /// <summary>
        /// Creates new instance of dhtmlxFormConnector
        /// </summary>
        /// <param name="data">Object to be sended to form</param>
        /// <param name="Properties">Properties to be rendered</param>
        /// <param name="IdPropertyName">Id property name</param>
        public dhtmlxFormConnector(object data, string Properties, string IdPropertyName)
            : base()
        {
            this._Request = new DataRequest(this, new List<object>(){data}, Properties,  IdPropertyName, "");
            this._Request.EnableSingleRecordSelect = true;

        }


        /// <summary>
        /// Creates new instance of dhtmlxFormConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxFormConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : this(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, false)
        {
            
        }



        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">XmlWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            xWriter.WriteStartElement("data");
            RenderSecurityKey(xWriter);
            RenderSections(xWriter);
        }

        /// <summary>
        /// Creates collection of dhtmlxFormDataItem objects from DataTable provided
        /// </summary>
        /// <param name="Rows">Table to create dhtmlxFormDataItem objects from</param>
        /// <returns>Collection of dhtmlxFormDataItem objects</returns>
        protected override List<dhtmlxFormDataItem> CreateDataItems(System.Data.DataTable Rows)
        {
            var items = new List<dhtmlxFormDataItem>();
            for (int i = 0; i < Rows.Rows.Count; i++)
            {
                var dataItem = new dhtmlxFormDataItem();
                if (this.Request.PrimaryKeyField != null)
                    dataItem.ID = Convert.ToString(Rows.Rows[i][this.Request.PrimaryKeyField.ExternalName]);


                for (var j = 0; j < Rows.Columns.Count; j++)
                {
                    if (!(this._Request.IdAppended && (Rows.Columns[j].ColumnName == this.Request.PrimaryKeyField.ExternalName)))
                        dataItem.DataFields.Add(Rows.Columns[j].ColumnName, Tools.ConvertToString(Rows.Rows[i][Rows.Columns[j]]));
                }
             //   foreach (DataColumn col in Rows.Columns)
            //        dataItem.DataFields.Add(col.ColumnName, Tools.ConvertToString(Rows.Rows[i][col]));
                dataItem.Index = i + this.Request.StartIndex;
                items.Add(dataItem);
            }

            return items;
           

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        protected override List<dhtmlxFormDataItem> _CreateDataItems(System.Collections.IEnumerable objects, Dictionary<string, System.Reflection.PropertyInfo> properties)
        {
            var items = new List<dhtmlxFormDataItem>();
            int i = 0;
            foreach (var item in objects)
            {
                var dataItem = new dhtmlxFormDataItem();
                if (this.Request.PrimaryKeyField != null && properties.ContainsKey(this.Request.PrimaryKeyField.InternalName))
                    dataItem.ID = Convert.ToString(properties[this.Request.PrimaryKeyField.InternalName].GetValue(item, null));

                foreach (var p in properties)
                {
                    if (!(this._Request.IdAppended && (p.Key == this.Request.PrimaryKeyField.ExternalName)))
                    {

                        dataItem.DataFields.Add(p.Key, Tools.ConvertToString(p.Value.GetValue(item, null)));
                    }
                }

                dataItem.Index = i + this.Request.StartIndex;
                i++;
                items.Add(dataItem);
            }

            return items;
        }

    }
}

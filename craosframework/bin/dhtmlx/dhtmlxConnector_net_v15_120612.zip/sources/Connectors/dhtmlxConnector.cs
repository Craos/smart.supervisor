﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data;
using System.Xml;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Represents basic connector functionality 
    /// </summary>
    /// <typeparam name="T">Type of item connector will operate</typeparam>
    public abstract class dhtmlxConnector<T>: IdhtmlxConnector
        where T: dhtmlxDataItem
    {

        private Dictionary<string, string> _Sections = new Dictionary<string, string>();
        /// <summary>
        /// Sections
        /// </summary>
        public Dictionary<string, string> Sections { get { return _Sections; } }

        /// <summary>
        /// Reference to DataRequest object
        /// </summary>
        protected DataRequest _Request = null;
        
        /// <summary>
        /// Gets reference to DataRequest object that is responsible for requests handling
        /// </summary>
        public virtual DataRequest Request
        {
            get
            {
                return this._Request;
            }
        }


        /// <summary>
        /// Processes client commands token from QueryString and Form collections
        /// </summary>
        /// <param name="QueryString">QueryString collection of client request</param>
        /// <param name="Form">Form collection of client request</param>
        public virtual void ProcessRequest(NameValueCollection QueryString, NameValueCollection Form)
        {
            if (this.Begin != null)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling Begin event");
#endif
                #endregion
                this.Begin(this, EventArgs.Empty);
            }
            this.AttachProxyEvents();
            this.Request.ProcessRequest(QueryString, Form);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="writer"></param>
        internal virtual void RenderSecurityKey(IdhtmlxWriter writer){
            if (ConnectorSecurity.SecurityKey)
            {
                if (HttpContext.Current.Session != null && HttpContext.Current.Session[CSRFSequrity.Var] != null)
                {
                    writer.WriteAttribute(CSRFSequrity.Var, (string)HttpContext.Current.Session[CSRFSequrity.Var]);
                }
            }
        }

        /// <summary>
        /// Add event listeners to DataRequest events to make their easy access by own events system
        /// </summary>
        private void AttachProxyEvents()
        {
            this.Request.OnDBError += delegate(object sender, DataActionProcessingEventArgs e) { if (this.OnDBError != null) this.OnDBError(this, e); };

            this.Request.BeforeProcessing += delegate(object sender, DataActionProcessingEventArgs e) { if (this.BeforeDataActionProcessing != null) this.BeforeDataActionProcessing(this, e); };
            this.Request.BeforeProcessing += delegate(object sender, DataActionProcessingEventArgs e) { if (this.BeforeProcessing != null) this.BeforeProcessing(this, e); };

            this.Request.AfterProcessing += delegate(object sender, DataActionProcessingEventArgs e) { if (this.DataActionProcessed != null) this.DataActionProcessed(this, e); };

            this.Request.AfterProcessing += delegate(object sender, DataActionProcessingEventArgs e) { if (this.AfterProcessing != null) this.AfterProcessing(this, e); };

            this.Request.BeforeInsert += delegate(object sender, DataActionProcessingEventArgs e) { if (this.BeforeInsert != null) this.BeforeInsert(this, e); };

            this.Request.AfterInsert += delegate(object sender, DataActionProcessingEventArgs e) { if (this.AfterInsert != null) this.AfterInsert(this, e); };
            this.Request.AfterInsert += delegate(object sender, DataActionProcessingEventArgs e) { if (this.Inserted != null) this.Inserted(this, e); };
            
            this.Request.BeforeUpdate += delegate(object sender, DataActionProcessingEventArgs e) { if (this.BeforeUpdate != null) this.BeforeUpdate(this, e); };
            this.Request.AfterUpdate += delegate(object sender, DataActionProcessingEventArgs e) { if (this.Updated != null) this.Updated(this, e); };
            this.Request.AfterUpdate += delegate(object sender, DataActionProcessingEventArgs e) { if (this.AfterUpdate != null) this.AfterUpdate(this, e); };
            
            this.Request.BeforeDelete += delegate(object sender, DataActionProcessingEventArgs e) { if (this.BeforeDelete != null) this.BeforeDelete(this, e); };
            this.Request.AfterDelete += delegate(object sender, DataActionProcessingEventArgs e) { if (this.Deleted != null) this.Deleted(this, e); };
            this.Request.AfterDelete += delegate(object sender, DataActionProcessingEventArgs e) { if (this.AfterDelete != null) this.AfterDelete(this, e); };
           
            this.Request.BeforeSelect += delegate(object sender, EventArgs e) { if (this.BeforeSelect != null) this.BeforeSelect(this, e); };
            this.Request.AfterSelect += delegate(object sender, DataSelectedEventArgs e) { if (this.Selected != null) this.Selected(this, e); };
            this.Request.AfterSelect += delegate(object sender, DataSelectedEventArgs e) { if (this.AfterSelect != null) this.AfterSelect(this, e); };

        }

        /// <summary>
        /// Renders processing results into current response
        /// </summary>
        /// <param name="response">HttpResponse object where to put results to</param>
        public virtual void RenderResponse(HttpResponse response)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering response");
#endif
            #endregion
            this.RenderResponseHeader(response);
            StringBuilder sb = new StringBuilder();

            var xWriter = new dhtmlxXMLWriter(sb, response);
            this.Render(xWriter);
          
            response.Write(xWriter.GetResult());
        }

        /// <summary>
        /// Renders processing results into IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter object where to put results to</param>
        public virtual void Render(IdhtmlxWriter xWriter)
        {
            this.Request.Render(xWriter);
        }
        

        /// <summary>
        /// Renders and prepares xml specific headers
        /// </summary>
        /// <param name="response">HttpResponse object to use</param>
        protected virtual void RenderResponseHeader(HttpResponse response)
        {
            response.ContentType = "text/xml";
            response.Write("<?xml version=\"1.0\" encoding=\"" + response.HeaderEncoding.BodyName + "\"?>");
        }

        /// <summary>
        /// Renders DataTable object into IdhtmlxWriter using connector-specific format
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter object to use for rendering</param>
        /// <param name="RowsToRender">Data to render</param>
        /// <param name="TotalRowsCount">Total rows count in case if RowsToRender doesn't contain all data</param>
        public virtual void RenderData(IdhtmlxWriter xWriter, System.Data.DataTable RowsToRender, int TotalRowsCount)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering 'Select' result");
#endif
            #endregion
            this.BeginRenderContent(xWriter, TotalRowsCount);
            if (this.BeforeOutput != null)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling BeforeOutput event");
#endif
                #endregion
                this.BeforeOutput(this, new RenderEventArgs(xWriter));
            }
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering children");
#endif
            #endregion
            this.RenderChildren(xWriter, this.CreateDataItems(RowsToRender));
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Closing response");
#endif
            #endregion
            this.EndRenderContent(xWriter, TotalRowsCount);

            if (this.End != null)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling End event");
#endif
                #endregion
                this.End(this, new RenderEventArgs(xWriter));
            }
        }
        /// <summary>
        /// Renders DataTable object into IdhtmlxWriter using connector-specific format
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter object to use for rendering</param>
        /// <param name="RowsToRender">Data to render</param>
        /// <param name="TotalRowsCount">Total rows count in case if RowsToRender doesn't contain all data</param>
        public virtual void RenderData(IdhtmlxWriter xWriter, System.Collections.IEnumerable RowsToRender, int TotalRowsCount)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering 'Select' result");
#endif
            #endregion
            this.BeginRenderContent(xWriter, TotalRowsCount);
            if (this.BeforeOutput != null)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling BeforeOutput event");
#endif
                #endregion
                this.BeforeOutput(this, new RenderEventArgs(xWriter));
            }
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering children");
#endif
            #endregion
            this.RenderChildren(xWriter, this.CreateDataItems(RowsToRender));
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Closing response");
#endif
            #endregion
            this.EndRenderContent(xWriter, TotalRowsCount);

            if (this.End != null)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling End event");
#endif
                #endregion
                this.End(this, new RenderEventArgs(xWriter));
            }
        }

        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected virtual void BeginRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            xWriter.WriteStartDocument("data");
            RenderSecurityKey(xWriter);
            RenderSections(xWriter);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="xWriter"></param>
        protected virtual void RenderSections(IdhtmlxWriter xWriter)
        {
            foreach (var sec in this.Sections)
            {
                xWriter.WriteStartElement(sec.Key);
                xWriter.WriteRawString(sec.Value);
                xWriter.WriteEndElement();
            }
        }

        /// <summary>
        /// Creates collection of connector specific data items from DataTable provided
        /// </summary>
        /// <param name="Rows">DataTable to create items from</param>
        /// <returns>Collection of connector specific data items</returns>
        protected abstract List<T> CreateDataItems(DataTable Rows);


        /// <summary>
        /// Creates collection of connector specific data items from IEnumerable provided
        /// </summary>
        /// <param name="objects">Objects collection to create items from</param>
        /// <returns></returns>
        protected List<T> CreateDataItems(IEnumerable objects)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Converting IEnumerable to connector specific data items");
#endif
            #endregion
            if(objects != null){
                object first = null;  
                foreach (var obj in objects)
                {             
                    first = obj;             
                    break;
                }
                if(first != null){
#region LOG ENTRY
#if !NO_LOG
                    Log.WriteLine(this, "Getting public properties of data item");
#endif
#endregion
                    var parser = new ObjectParser();
                    var properties = GetProperties(first, parser);
                    if (properties != null)
                    {
                        #region LOG ENTRY
#if !NO_LOG
                        Log.WriteLine(this, "Processing IEnumerable");
#endif
                        #endregion
                        return _CreateDataItems(objects, properties);
                    }
                }
            }
            return new List<T>();
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        protected abstract List<T> _CreateDataItems(IEnumerable objects, Dictionary<string, System.Reflection.PropertyInfo> properties);

        /// <summary>
        /// Gets list of requested properties from custom data object
        /// </summary>
        /// <param name="source"></param>
        /// <param name="parser"></param>
        /// <returns></returns>
        internal virtual Dictionary<string, System.Reflection.PropertyInfo> GetProperties(object source, ObjectParser parser)
        {
            
            return parser.GetProperties(source
                , this.Request.RequestedFields
                , this.Request.PrimaryKeyField
                , this.Request.ParentRecordIDField);
        
        }

        /// <summary>
        /// Renders children (data items) into IdhtmlxWriter provided
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render response to</param>
        /// <param name="dataItems">Data items to render</param>
        protected virtual void RenderChildren(IdhtmlxWriter xWriter, List<T> dataItems)
        {
            
            foreach (T dataItem in dataItems)
            {
                if (this.ItemPrerender != null || this.BeforeRender != null)
                {
                    if(this.ItemPrerender != null)
                        dataItem.Prerender += delegate(object sender, EventArgs e) { this.ItemPrerender(this, new ItemPrerenderEventArgs<T>(sender as T)); };
                    if(this.BeforeRender != null)
                        dataItem.Prerender += delegate(object sender, EventArgs e) { this.BeforeRender(this, new ItemPrerenderEventArgs<T>(sender as T)); };

                }
                dataItem.Render(xWriter);
            }
        }

        /// <summary>
        /// Renders results of data actions into IdhtmlxWriter provided
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render response to</param>
        /// <param name="ResultsToRender">Collection of DataAction object to render</param>
        public virtual void RenderActions(IdhtmlxWriter xWriter, IEnumerable<DataAction> ResultsToRender)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering data actions: [" + Tools.Join(ResultsToRender, ", ") + "]");
#endif
            #endregion
            
            xWriter.WriteStartDocument("data");
            if (this.BeforeOutput != null)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling BeforeOutput event");
#endif
                #endregion
                this.BeforeOutput(this, new RenderEventArgs(xWriter));
            }
            

            foreach (DataAction actionResult in ResultsToRender)
            {
               
                xWriter.WriteStartElement("action");
                xWriter.WriteAttribute("type", actionResult.ActionType == ActionType.Custom ? actionResult.CustomActionName : actionResult.ActionType.ToString().ToLower());
                xWriter.WriteAttribute("sid", Convert.ToString(actionResult.PrimaryKeyValue));
                xWriter.WriteAttribute("tid", Convert.ToString(actionResult.PostoperationalPrimaryKeyValue));
                foreach (KeyValuePair<string, string> attrib in actionResult.CustomAttribs)
                    xWriter.WriteAttribute(attrib.Key, attrib.Value);
                if (!string.IsNullOrEmpty(actionResult.Details))
                    xWriter.WriteString(actionResult.Details);
                xWriter.WriteEndElement();
               
            }
             xWriter.WriteEndDocument();

            if (this.End != null)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling End event");
#endif
                #endregion
                this.End(this, new RenderEventArgs(xWriter));
            }
        }



        #region Events and Handlers

        /// <summary>
        /// Event to be called before item is going to render
        /// </summary>
        [Obsolete("ItemPrerender event is deprecated, use BeforeRender event")]
        public event EventHandler<ItemPrerenderEventArgs<T>> ItemPrerender;
        /// <summary>
        /// Event to be called before item is going to render
        /// </summary>
        public event EventHandler<ItemPrerenderEventArgs<T>> BeforeRender;

        /// <summary>
        /// Event to be called before items items are going to render. This event is mostly necessary for writing additional xml info into response (e.g. grid header configuration)
        /// </summary>
        public event EventHandler<RenderEventArgs> BeforeOutput;
        /// <summary>
        /// Checks if event handler is not null(so it can be checked in extended classes)
        /// </summary>
        public bool HasBeforeOutputHandler
        {
            get { return BeforeOutput != null; }
        }
        /// <summary>
        /// Event caller which can be used in extended classes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void FireBeforeOutputEvent(object sender, RenderEventArgs args)
        {
            this.BeforeOutput(sender, args);
        }
        /// <summary>
        /// Event to be fired when all connector activity has been done
        /// </summary>
        public event EventHandler<RenderEventArgs> End;
        /// <summary>
        /// Checks if event handler is not null(so it can be checked in extended classes)
        /// </summary>
        public bool HasEndHandler
        {
            get { return End != null; }
        }
        /// <summary>
        /// Event caller which can be used in extended classes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void FireEndEvent(object sender, RenderEventArgs args)
        {
            this.End(sender, args);
        }
        /// <summary>
        /// Event to be fired before any connector activity starts
        /// </summary>
        public event EventHandler Begin;
        /// <summary>
        /// Checks if event handler is not null(so it can be checked in extended classes)
        /// </summary>
        public bool HasBeginHandler
        {
            get { return Begin != null; }
        }
        /// <summary>
        /// Event caller which can be used in extended classes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void FireBeginEvent(object sender, RenderEventArgs args)
        {
            this.Begin(sender, args);
        }
        #endregion
        #region Proxy events

        /// <summary>
        /// Event to be fired on database error
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> OnDBError;
   
        /// <summary>
        /// Event to be fired before any DataAction is executed
        /// </summary> 
        [Obsolete("BeforeDataActionProcessing event is deprecated, use BeforeProcessing event")]
        public event EventHandler<DataActionProcessingEventArgs> BeforeDataActionProcessing;

       
        /// <summary>
        /// Event to be fired before any DataAction is executed
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> BeforeProcessing;

        /// <summary>
        /// Event to be fired after any DataAction was executed
        /// </summary>
        [Obsolete("DataActionProcessed event is deprecated, use AfterProcessing event")]
        public event EventHandler<DataActionProcessingEventArgs> DataActionProcessed;
        /// <summary>
        /// Event to be fired after any DataAction was executed
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> AfterProcessing;

        /// <summary>
        /// Event to be fired before any insert DataAction is executed
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> BeforeInsert;
    
        /// <summary>
        /// Event to be fired after insert DataAction was executed
        /// </summary>
        [Obsolete("Inserted event is deprecated, use AfterInsert event")]
        public event EventHandler<DataActionProcessingEventArgs> Inserted;
   
        /// <summary>
        /// Event to be fired after insert DataAction was executed
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> AfterInsert;

        /// <summary>
        /// Event to be fired before any update DataAction is executed
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> BeforeUpdate;
   
        /// <summary>
        /// Event to be fired after Update DataAction was executed
        /// </summary>
        [Obsolete("Updated event is deprecated, use AfterUpdate event")]
        public event EventHandler<DataActionProcessingEventArgs> Updated;
  
        /// <summary>
        /// Event to be fired after Update DataAction was executed
        /// </summary>  
        public event EventHandler<DataActionProcessingEventArgs> AfterUpdate;

        /// <summary>
        /// Event to be fired before any delete DataAction is executed
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> BeforeDelete;
   
        /// <summary>
        /// Event to be fired after delete DataAction was executed
        /// </summary>
        [Obsolete("Deleted event is deprecated, use AfterDelete event")]
        public event EventHandler<DataActionProcessingEventArgs> Deleted;
     
        /// <summary>
        /// Event to be fired after delete DataAction was executed
        /// </summary>
        public event EventHandler<DataActionProcessingEventArgs> AfterDelete;

        /// <summary>
        /// Event to be fired before data select
        /// </summary>
        public event EventHandler BeforeSelect;
   
        /// <summary>
        /// Event to be fired after select results were retrieved
        /// </summary>
        [Obsolete("Selected event is deprecated, use AfterSelect event")]
        public event EventHandler<DataSelectedEventArgs> Selected;
    
         /// <summary>
        /// Event to be fired after select results were retrieved
        /// </summary>
        public event EventHandler<DataSelectedEventArgs> AfterSelect;

        #endregion
       
        /// <summary>
        /// Writes end tags of response header
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected virtual void EndRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            xWriter.WriteEndDocument();
        }

        /// <summary>
        /// Decodes field name to Field object
        /// </summary>
        /// <param name="EncodedField">Encoded field name token from QueryString</param>
        /// <returns>Field object that corresponds EncodedField, or null</returns>
        public virtual Field DecodeField(string EncodedField)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Encoding query field: " + EncodedField);
#endif
            #endregion

            string encField = EncodedField;// Regex.Replace(EncodedField, "^[^_]*.", "");
            Regex cellsPattern = new Regex("c[0-9]+$");
            if (cellsPattern.IsMatch(encField))
           // if (encField.StartsWith("c"))
            {
                encField = encField.Substring(1);
                int colIndex = Int32.Parse(encField);
                if (this.Request.RequestedFields.Count > colIndex)
                    return this.Request.RequestedFields[colIndex];
            }
            else 
            {
                if(this.Request.RequestedFields != null)
                    foreach(var field in this.Request.RequestedFields)
                        if (field.ExternalName == EncodedField)
                            return field;
            }
            return null;
        }
        /// <summary>
        /// gets single record by id
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>data item</returns>
        public virtual T GetRecord(string id)
        {
           var record = this.Request.GetRecord(id);
           var items = this.CreateDataItems(record);
           if (items.Count == 0)
               return null;
           return items[0];
        }


        private dhtmlxFieldsCollection _ExtraFields = new dhtmlxFieldsCollection();

        /// <summary>
        /// Gets reference to collection of Field for being requested but not rendered
        /// </summary>
        public dhtmlxFieldsCollection ExtraFields
        {
            get
            {
                return this._ExtraFields;
            }
        }

        /// <summary>
        /// Parses columns and put them into ExtraFields collection
        /// </summary>
        /// <param name="ExtraColumnNames">SQL string that contains extra column names</param>
        protected void ParseExtraColumns(string ExtraColumnNames)
        {
            if (!string.IsNullOrEmpty(ExtraColumnNames))
                foreach (string ColumnExpression in ExtraColumnNames.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    this.ExtraFields.Add(this.Request.Adapter.ParseField(ColumnExpression));
        }

        /// <summary>
        /// Creates new instance of dhtmlxConnector
        /// </summary>
        public dhtmlxConnector()
        {
            this.BeforeSelect += new EventHandler(dhtmlxConnector_BeforeSelect);
        }

        /// <summary>
        /// Attach BeforeSelect hook in order to make sure that ExtraFields are also included into request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dhtmlxConnector_BeforeSelect(object sender, EventArgs e)
        {
            if(this.Request.RequestedFields != null)
            this.Request.RequestedFields = this.Request.RequestedFields.Union(this.ExtraFields).ToFieldsCollection();
        }

        /// <summary>
        /// Sets number of rows returned by default
        /// </summary>
        /// <param name="RowsPerPage">Number of rows to be returned during initial request</param>
        public void SetDynamicLoading(int RowsPerPage)
        {
            this.Request.Count = RowsPerPage;
        }
     
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Xml;
using System.Xml.Linq;
namespace dhtmlxConnectors
{
    /// <summary>
    /// represents dhtmlxGrid configuration
    /// </summary>
    public class dhtmlxGridConfiguration
    {
        #region fields
        /// <summary>
        /// delimiter in parameters string
        /// </summary>
        protected string _HeaderDelimiter = ",";
        /// <summary>
        /// header columns names
        /// </summary>
   //     protected HttpContext Context = null;
    //    protected List<int> Options = new List<int>();
        protected string[] HeaderNames = { };
        /// <summary>
        /// header columns width
        /// </summary>
        protected string[] HeaderWidths = { };
        /// <summary>
        /// columns align
        /// </summary>
        protected string[] HeaderAlign = { };
        /// <summary>
        /// columns vertical align
        /// </summary>
        protected string[] HeaderVAlign = { };
        /// <summary>
        /// columns types
        /// </summary>
        protected string[] HeaderTypes = { };
        /// <summary>
        /// header columns sorts
        /// </summary>
        protected string[] HeaderSorts = { };
        /// <summary>
        /// header columns colors
        /// </summary>
        protected string[] HeaderColors = { };
        /// <summary>
        /// header columns hidden columns
        /// </summary>
        protected string[] HeaderHidden = { };
        /// <summary>
        /// header columns ids
        /// </summary>
        protected string[] HeaderIds = { };

        /// <summary>
        /// FooterAttaches
        /// </summary>
        protected List<Dictionary<string, string[]>> FooterAttaches = new List<Dictionary<string, string[]>>();

        /// <summary>
        /// HeaderAttaches
        /// </summary>
        protected List<Dictionary<string, string[]>> HeaderAttaches = new List<Dictionary<string, string[]>>();

        #endregion
    //    /// <summary>
    //    /// creates instance of dhtmlxGridConfiguration
    //    /// </summary>
   //     public dhtmlxGridConfiguration(HttpContext context)
   //     {
   //         Context = context;
   //     }

        /// <summary>
        /// HeaderWidthsUnits (pixels or percents)
        /// </summary>
        protected string HeaderWidthsUnits = "";

        /// <summary>
        /// get or set header delimiter
        /// </summary>
        public string HeaderDelimiter { get { return _HeaderDelimiter; } set { _HeaderDelimiter = value; } }

       
        /// <summary>
        /// set dhtmlxGrid headers names
        /// <param name="names">sting, headers names separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetHeader(string names) 
        {         
            HeaderNames = ParseParamArray(names);           
        }

        /// <summary>
        /// set dhtmlxGrid columns widths in pixels
        /// <param name="wp">sting, width values separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetInitWidths(string wp) {                                                          
		    HeaderWidths = ParseParamArray(wp);
		    HeaderWidthsUnits = "px";
	    }

        /// <summary>
        /// set dhtmlxGrid columns widths in percents
        /// <param name="wp">sting, width values separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetInitWidthsP(string wp) {
            SetInitWidths(wp);
            HeaderWidthsUnits = "%";
        }

        /// <summary>
        /// set dhtmlxGrid columns align
        /// <param name="str">sting, align values separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetColAlign(string str) {
            string[] variants = { "right", "left", "center", "justify" };
            HeaderAlign = ParseParamArray(str, variants, "left");
        }

        /// <summary>
        /// set dhtmlxGrid columns vertical align
        /// <param name="str">sting, align values separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetColVAlign(string str) { 
            string[] variants = { "baseline", "sub", "super", "top", "text-top", "middle", "bottom", "text-bottom" };
            HeaderVAlign = ParseParamArray(str, variants, "top");
        }

        /// <summary>
        /// set dhtmlxGrid columns types
        /// <param name="str">sting, columns types separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetColTypes(string str) {
            HeaderTypes = ParseParamArray(str);
        }

        /// <summary>
        /// set dhtmlxGrid columns sortings
        /// <param name="str">sting, columns sortings separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetColSorting(string str) {
            HeaderSorts = ParseParamArray(str);
        }

        /// <summary>
        /// set dhtmlxGrid columns colors
        /// <param name="str">sting, columns colors separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetColColor(string str) {
            HeaderColors = ParseParamArray(str);
        }

        /// <summary>
        /// set dhtmlxGrid columns hidden
        /// <param name="str">sting, columns 'is hidden' values separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetColHidden(string str) {
            HeaderHidden = ParseParamArray(str);
        }

        /// <summary>
        /// set dhtmlxGrid columns ids
        /// <param name="str">sting, columns ids separated by delimiter(',' by default)</param>
        /// </summary>
        public void SetColIds(string str) {
            HeaderIds = ParseParamArray(str);
        }


        /// <summary>
        /// attachs dhtmlxGrid header
        /// <param name="values">header values separated by delimiter(',' by default)</param>
        /// </summary>
        public void AttachHeader(string values) { 
            AttachHeader(values, null, false);
           
        }
        /// <summary>
        /// attachs dhtmlxGrid header
        /// <param name="values">header values separated by delimiter(',' by default)</param>
        /// <param name="styles">header styles separated by delimiter(',' by default)</param>   
        /// </summary>
        public void AttachHeader(string values, string styles) { 
            AttachHeader(values, styles, false);
           
        }

        /// <summary>
        /// attachs dhtmlxGrid header
        /// <param name="values">header values separated by delimiter(',' by default)</param>
        /// <param name="styles">header styles separated by delimiter(',' by default)</param>
        /// <param name="footer">is its footer </param>
        /// </summary>
        public void AttachHeader(string values, string styles, bool footer) { 
            var header = new Dictionary<string, string[]>();
            header.Add("values", ParseParamArray(values));
		
		    if (styles != null) {
			    header.Add("styles", ParseParamArray(styles));
		    } else {
			    header.Add("styles", null);
		    }
		    if (footer)
			    FooterAttaches.Add(header);
		    else
			    HeaderAttaches.Add(header);      
        }



        /// <summary>
        /// attachs dhtmlxGrid footer
        /// <param name="values">footer values separated by delimiter(',' by default)</param>
        /// <param name="styles">footer styles separated by delimiter(',' by default)</param>
        /// </summary>
        public void AttachFooter(string values, string styles) { 
            AttachHeader(values, styles, true);
        }
        /// <summary>
        /// attachs dhtmlxGrid footer
        /// <param name="values">footer values separated by delimiter(',' by default)</param>
        /// </summary>
        public void AttachFooter(string values) { 
            AttachHeader(values, null, true);
        }

        /// <summary>
        /// convert list(string) of parameters to an array
        /// <param name="param">string of parameters separated by delimiter(',' by default)</param>
        /// <param name="check"></param>
        /// <param name="def"></param>
        /// <returns>array of values</returns>
        /// </summary>
        private string[] ParseParamArray(string param, string[] check, string def){
            string[] delimiter = { HeaderDelimiter };
            var nms = param.Split(delimiter, StringSplitOptions.None);
				
		    if (check != null){
			    for (var i=0; i < nms.Length; i++) { 
				    if (!check.Contains(nms[i]))
					    nms[i] = def;
			    }
		    }
		    return nms;
	    }
        /// <summary>
        /// convert list(string) of parameters to an array
        /// <param name="param">string of parameters separated by delimiter(',' by default)</param>
        /// <returns>array of values</returns>
        /// </summary>
        private string[] ParseParamArray(string param){         
		    return ParseParamArray(param, null, "");
	    }
        /// <summary>
        /// convert list(string) of parameters to an array
        /// <param name="param">string of parameters separated by delimiter(',' by default)</param>
        /// <param name="check"></param>
        /// <returns>array of values</returns>
        /// </summary>
        private string[] ParseParamArray(string param, string[] check){
            return ParseParamArray(param, check, "");
	    }


        /// <summary>
        /// convert list of parameters to an array
        /// <param name="param">list of parameters separated by delimiter(',' by default)</param>
        /// <param name="check"></param>
        /// <param name="def"></param>
        /// <returns>array of values</returns>
        /// </summary>
        private string[] ParseParamArray(string[] param, string[] check, string def)
        {
            if (check != null)
            {
                for (var i = 0; i < param.Length; i++)
                {
                    if (!check.Contains(param[i]))
                        param[i] = def;
                }
            }
            return param;
        }
           /// <summary>
        /// convert list of parameters to an array
        /// <param name="param">list of parameters separated by delimiter(',' by default)</param>
        /// <returns>array of values</returns>
        /// </summary>
        private string[] ParseParamArray(string[] param){         
		    return ParseParamArray(param, null, "");
	    }
        /// <summary>
        /// convert list(string) of parameters to an array
        /// <param name="param">list of parameters separated by delimiter(',' by default)</param>
        /// <param name="check"></param>
        /// <returns>array of values</returns>
        /// </summary>
        private string[] ParseParamArray(string[] param, string[] check){
            return ParseParamArray(param, check, "");
	    }
        /// <summary>
        /// auto fill config settings
        /// <param name="mode">auto fill mode</param>
        /// </summary>
        private void AutoFill(bool mode){
		    string headerWidths = "";
		    string headerTypes = "";
		    string headerSorts = "";
		    string headerAttaches = "";
		
		    for (var i=0; i < HeaderNames.Length; i++) { 
			    headerWidths += "100,";
			    headerTypes += "ro,";
			    headerSorts += "connector,";
			    headerAttaches += "#connector_text_filter,";
		    }
            if (HeaderNames.Length > 0)
            {
                headerWidths = headerWidths.Substring(0, headerWidths.Length - 1);
                headerTypes = headerWidths.Substring(0, headerWidths.Length - 1);
                headerSorts = headerWidths.Substring(0, headerWidths.Length - 1);
                headerAttaches = headerWidths.Substring(0, headerWidths.Length - 1);
            }
		    if (HeaderWidths == null)
			    SetInitWidths(headerWidths);
		    if (HeaderTypes == null)
			    SetColTypes(headerTypes);
			
		    if (mode){
			    if (HeaderSorts == null)
				    SetColSorting(headerSorts);
			    AttachHeader(headerAttaches);
		    }
	    }
/*
        /// <summary>
        /// sets columns with options list      
        /// </summary>
        protected void DefineOptions()
        {
            //var context = new HttpContext(
            foreach (var param in Context.Request.Params.AllKeys)           
                if (param == "dhx_colls")
                    return;

            var fillList = new List<int>();
            for (var i = 0; i < HeaderNames.Length; i++)
                if (HeaderTypes[i] == "co" || HeaderTypes[i] == "coro")
                    fillList.Add(i);
            
            for (var i = 0; i < HeaderAttaches.Count; i++)
                for (var j = 0; j <  HeaderAttaches[i]["values"].Length; j++)           
                    if(HeaderAttaches[i]["values"][j] == "#connector_select_filter" || HeaderAttaches[i]["values"][j] == "#select_filter")
                        fillList.Add(j);
            Options = fillList;   
            
        

        }*/

        /// <summary>
        /// renders header
        /// <param name="xWriter">XmlWriter</param>
        /// </summary>
        public void RenderHeader(IdhtmlxWriter xWriter)
        {
            xWriter.WriteStartElement("head");
            for (var i = 0; i < HeaderNames.Length; i++ )
            {
                xWriter.WriteStartElement("column");
                if (HeaderTypes.Length > i)
                    xWriter.WriteAttribute("type", HeaderTypes[i]);
                if (HeaderWidths.Length > i)
                    xWriter.WriteAttribute("width", HeaderWidths[i]);
                if(HeaderIds.Length > i)
                    xWriter.WriteAttribute("id", HeaderIds[i]);
                if (HeaderAlign.Length > i)
                    xWriter.WriteAttribute("align", HeaderAlign[i]);
                if (HeaderVAlign.Length > i)
                    xWriter.WriteAttribute("valign", HeaderVAlign[i]);
                if (HeaderSorts.Length > i)
                    xWriter.WriteAttribute("sort", HeaderSorts[i]);
                if (HeaderColors.Length > i)
                    xWriter.WriteAttribute("color", HeaderColors[i]);
                if (HeaderHidden.Length > i)
                    xWriter.WriteAttribute("hidden", HeaderHidden[i]);

                xWriter.WriteString(HeaderNames[i]);
                xWriter.WriteEndElement();
            }
            xWriter.WriteStartElement("settings");
                xWriter.WriteStartElement("colwidth");
                xWriter.WriteString(HeaderWidthsUnits);
                xWriter.WriteEndElement();
            xWriter.WriteEndElement();

            if(FooterAttaches != null || FooterAttaches != null)
                xWriter.WriteStartElement("afterInit");

            for (var i = 0; i < HeaderAttaches.Count; i++)
            {
                xWriter.WriteStartElement("call");
                xWriter.WriteAttribute("command", "attachHeader");
                xWriter.WriteStartElement("param");
                xWriter.WriteString(String.Join(",", HeaderAttaches[i]["values"]));
                xWriter.WriteEndElement();
                if (HeaderAttaches[i]["styles"] != null)
                {
                    xWriter.WriteStartElement("param");
                    xWriter.WriteString(String.Join(",", HeaderAttaches[i]["styles"]));
                    xWriter.WriteEndElement();
                }
                xWriter.WriteEndElement();
            }

            for (var i = 0; i < FooterAttaches.Count; i++)
            {
                xWriter.WriteStartElement("call");
                xWriter.WriteAttribute("command", "attachFooter");
                xWriter.WriteStartElement("param");
                xWriter.WriteString(String.Join(",", FooterAttaches[i]["values"]));
                xWriter.WriteEndElement();
                if (HeaderAttaches[i]["styles"] != null)
                {
                    xWriter.WriteStartElement("param");
                    xWriter.WriteString(String.Join(",", FooterAttaches[i]["styles"]));
                    xWriter.WriteEndElement();
                }
                xWriter.WriteEndElement();
            }
            if(FooterAttaches != null || FooterAttaches != null)
                xWriter.WriteEndElement();

            xWriter.WriteEndElement();
		
        }

        /// <summary>
        /// render configuration header to pdf/excel generators format 
        /// </summary>
        /// <returns>configuration string</returns>
        public string RenderForExport()
        {
            string export = "";
            export += "<head>";
            export += "<columns>";
            for (var i = 0; i < HeaderNames.Length; i++)
            {
                export += "<column ";
                if (HeaderTypes.Length > i)
                    export += "type='" + HeaderTypes[i] + "' ";
                if (HeaderWidths.Length > i)
                    export += "width='" + HeaderWidths[i] + "' ";
                if (HeaderIds.Length > i)
                    export += "id='" + HeaderIds[i] + "' ";
                if (HeaderAlign.Length > i)
                    export += "align='" + HeaderAlign[i] + "' ";
                if (HeaderVAlign.Length > i)
                    export += "valign='" + HeaderVAlign[i] + "' ";
                if (HeaderSorts.Length > i)
                    export += "sort='" + HeaderSorts[i] + "' ";
                if (HeaderColors.Length > i)
                    export += "color='" + HeaderColors[i] + "' ";
                if (HeaderHidden.Length > i)
                    export += "hidden='" + HeaderHidden[i] + "' ";


                export += "><![CDATA[" + HeaderNames[i] + "]]>";
                export += "</column>";

            }
            export += "</columns>";

            if (HeaderAttaches != null && HeaderAttaches.Count != 0)
            {
                for (var i = 0; i < HeaderAttaches.Count; i++)
                {

                    export += "<columns>";
                    for (var j = 0; j < HeaderAttaches[i]["values"].Length; j++)
                    {
                        export += "<column ";
                        if (HeaderAttaches[i]["styles"] != null && HeaderAttaches[i]["styles"].Length > j && HeaderAttaches[i]["styles"][j] != "")
                        {
                            export += " " + HeaderAttaches[i]["styles"][j] + " ";
                        }

                        export += "><![CDATA[" + HeaderAttaches[i]["values"][j] + "]]>";
                        export += "</column>";

                    }
                    export += "</columns>";
                }

            }
            export += "</head>";
            if (FooterAttaches != null && FooterAttaches.Count != 0)
            {
                export += "<foot>";

                for (var i = 0; i < FooterAttaches.Count; i++)
                {
                    export += "<columns>";
                    for (var j = 0; j < FooterAttaches[i]["values"].Length; j++)
                    {
                        export += "<column ";
                        if (FooterAttaches[i]["styles"] != null && FooterAttaches[i]["styles"].Length > j && FooterAttaches[i]["styles"][j] != "")
                        {
                            export += " " + FooterAttaches[i]["styles"][j] + " ";
                        }

                        export += "><![CDATA[" + FooterAttaches[i]["values"][j] + "]]>";
                        export += "</column>";
                    }
                    export += "</columns>";
                }
                export += "</foot>";


            }
            return export;

        }
       
    }
    
}
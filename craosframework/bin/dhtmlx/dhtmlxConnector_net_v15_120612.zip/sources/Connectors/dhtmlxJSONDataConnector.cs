﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data;
using System.Xml;
using System.Collections.Specialized;
using System.Text.RegularExpressions;


namespace dhtmlxConnectors
{
    /// <summary>
    /// Serves dhtmlxJSONDataConnector client requests
    /// </summary>
	public class dhtmlxJSONDataConnector : dhtmlxConnector<dhtmlxJSONDataConnectorDataItem>, IdhtmlxConnector
	{
                /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="TableName">Select query to use for data retrieval</param>
        /// <param name="Columns">Type of adapter to use for communication with database engine</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxJSONDataConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base()
        {
            this._Request = new DataRequestSDT(this, TableName, Columns, PrimaryKeyColumnName, "", AdapterType, ConnectionString);
            this._Request.EnableSingleRecordSelect = true;
        }

        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxJSONDataConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : this(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, false)
        {
           
        }

        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxJSONDataConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, bool asIs)
            : base()
        {
            this._Request = new DataRequestSDT(this, SelectQuery, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs);
            this._Request.EnableSingleRecordSelect = true;
        }
       

        /// <summary>
        /// Creates collection of dhtmlxDataViewDataItem objects from DataTable provided
        /// </summary>
        /// <param name="Rows">Table to create dhtmlxComboItem objects from</param>
        /// <returns>Collection of dhtmlxComboItem objects</returns>
        protected override List<dhtmlxJSONDataConnectorDataItem> CreateDataItems(System.Data.DataTable Rows)
        {
            var items = new List<dhtmlxJSONDataConnectorDataItem>();
            for (int i = 0; i < Rows.Rows.Count; i++)
            {
                var dataItem = new dhtmlxJSONDataConnectorDataItem();
                if (this.Request.PrimaryKeyField != null)
                    dataItem.ID = Convert.ToString(Rows.Rows[i][this.Request.PrimaryKeyField.ExternalName]);
             //   foreach (DataColumn col in Rows.Columns)
             //       dataItem.DataFields.Add(col.ColumnName, Tools.ConvertToString(Rows.Rows[i][col]));
                for (var j = 0; j < Rows.Columns.Count; j++)
                {
                    if (!(this._Request.IdAppended && (Rows.Columns[j].ColumnName == this.Request.PrimaryKeyField.ExternalName)))
                        dataItem.DataFields.Add(Rows.Columns[j].ColumnName, Tools.ConvertToString(Rows.Rows[i][Rows.Columns[j]]));
                }
                dataItem.Index = i + this.Request.StartIndex;
                items.Add(dataItem);
            }

            return items;
           

        }
        /// <summary>
        /// Renders processing results into current response
        /// </summary>
        /// <param name="response">HttpResponse object where to put results to</param>
        public override void RenderResponse(HttpResponse response)
        {
            response.Output.NewLine = "\n";
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering response");
#endif
            #endregion
            this.RenderResponseHeader(response);
            StringBuilder sb = new StringBuilder();
            var xWriter = new dhtmlxJSONWriter(sb, response);
            this.Render(xWriter);
            
            response.Write(xWriter.GetResult());
            
        }

        /// <summary>
        /// Renders and prepares xml specific headers
        /// </summary>
        /// <param name="response">HttpResponse object to use</param>
        protected override void RenderResponseHeader(HttpResponse response)
        {
            response.ContentType = "text/plain";
           
        }

        /// <summary>
        /// Renders results of data actions into XmlWriter provided
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render response to</param>
        /// <param name="ResultsToRender">Collection of DataAction object to render</param>
        public override void RenderActions(IdhtmlxWriter xWriter, IEnumerable<DataAction> ResultsToRender)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering data actions: [" + Tools.Join(ResultsToRender, ", ") + "]");
#endif
            #endregion


            

            var is_xml = false;
            foreach (DataAction actionResult in ResultsToRender)
            {
                if (actionResult.ActionProtocol == ActionProtocol.Standart)
                {
                    is_xml = true;
                    break;
                }
            }

            var xml = new dhtmlxXMLWriter(new StringBuilder(), null);
            
            if (is_xml)
            {
                var req = (xWriter as dhtmlxJSONWriter).Response;
                req.ContentType = "text/xml";
                req.Write("<?xml version=\"1.0\" encoding=\"" + req.HeaderEncoding.BodyName + "\"?>");
                xml.WriteStartElement("data");
                (xWriter as dhtmlxJSONWriter).WriteRawString(xml.GetResult());
            }

            if (this.HasBeforeOutputHandler)
            {
                #region LOG ENTRY
                #if !NO_LOG
                Log.WriteLine(this, "Calling BeforeOutput event");
                #endif
                #endregion
                this.FireBeforeOutputEvent(this, new RenderEventArgs(xWriter));             
            }


            foreach (DataAction actionResult in ResultsToRender)
            {
                if (actionResult.ActionProtocol == ActionProtocol.SDT)
                {
                    if (actionResult.ActionType == ActionType.Error)
                        (xWriter as dhtmlxJSONWriter).WriteRawString("false");
                    else
                        (xWriter as dhtmlxJSONWriter).WriteRawString("true");
                    if (actionResult.ActionType == ActionType.Inserted)
                        (xWriter as dhtmlxJSONWriter).WriteRawString('\n' + Convert.ToString(actionResult.PostoperationalPrimaryKeyValue));
                }
                else
                {
                                 
                    xml.WriteStartElement("action");

                    xml.WriteAttribute("type", actionResult.ActionType == ActionType.Custom ? actionResult.CustomActionName : ConvertActionType(actionResult.ActionType));
                    xml.WriteAttribute("sid", Convert.ToString(actionResult.PrimaryKeyValue));
                    xml.WriteAttribute("tid", Convert.ToString(actionResult.PostoperationalPrimaryKeyValue));
                    foreach (KeyValuePair<string, string> attrib in actionResult.CustomAttribs)
                        xml.WriteAttribute(attrib.Key, attrib.Value);
                    if (!string.IsNullOrEmpty(actionResult.Details))
                        xml.WriteString(actionResult.Details);

                    xml.WriteEndElement();
                                 
                }
            }
            if (is_xml)
            { 
                xml.WriteEndElement();
                (xWriter as dhtmlxJSONWriter).WriteRawString(xml.GetResult());
            }


            if (this.HasEndHandler)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling End event");
#endif
                #endregion
                this.FireEndEvent(this, new RenderEventArgs(xWriter));
            }
        }
        /// <summary>
        /// converts action type to new connectors format
        /// </summary>
        /// <param name="type">ActionType</param>
        /// <returns>string</returns>
        private string ConvertActionType(ActionType type)
        {
            switch (type) {
                case ActionType.Deleted :
                    return "delete";
                case ActionType.Updated :
                    return "update";
                case ActionType.Inserted:
                    return "insert";
                default :
                    return type.ToString().ToLower();
            }
        }

    }

            
	
}

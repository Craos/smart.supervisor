﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Data item for dhtmlxComboConnector
    /// </summary>
    public class dhtmlxComboItem: dhtmlxDataItem
    {
        /// <summary>
        /// Gets or Sets value used for option identification (the same as ID)
        /// </summary>
        public string Value
        {
            get
            {
                return this.ID;
            }
            set
            {
                this.ID = value; ;
            }
        }

        /// <summary>
        /// Gets or Sets item's visible text
        /// </summary>
        public string Text
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or Sets selected state of the item
        /// </summary>
        public bool Selected
        {
            get;
            set;
        }

     /*   /// <summary>
        /// Renders item into response stream provided
        /// </summary>
        /// <param name="xWriter">XmlWriter to use for output</param>
        protected override void RenderContent(IdhtmlxWriter xWriter)
        {
        }*/
        /// <summary>
        /// Outputs DataItem content to IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderUserData(IdhtmlxWriter xWriter)
        {
            if (this.UserData != null && this.UserData.Count > 0)
            {
                foreach (KeyValuePair<string, string> pair in this.UserData)
                {
                    xWriter.WriteAttribute(pair.Key, pair.Value);
                }
            }
        }
        /// <summary>
        /// Outputs DataItem content to IdhtmlxWriter
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderStartContent(IdhtmlxWriter xWriter)
        {
            xWriter.WriteStartElement("option");
            if (!string.IsNullOrEmpty(this.Value))
                xWriter.WriteAttribute("value", this.Value);
            if (this.Selected)
                xWriter.WriteAttribute("selected", "true");
            xWriter.WriteString(this.Text);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data;
using System.Xml;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Collections;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Serves dhtmlxJSONDataConnector client requests
    /// </summary>
	public class dhtmlxDataJsonConnector : dhtmlxConnector<dhtmlxDataJsonConnectorDataItem>, IdhtmlxConnector
	{
                /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="TableName">Select query to use for data retrieval</param>
        /// <param name="Columns">Type of adapter to use for communication with database engine</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxDataJsonConnector(string TableName, string Columns, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base()
        {
            this._Request = new DataRequestSDT(this, TableName, Columns, PrimaryKeyColumnName, "", AdapterType, ConnectionString);
            this._Request.EnableSingleRecordSelect = true;
        }

        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        public dhtmlxDataJsonConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : this(SelectQuery, PrimaryKeyColumnName, AdapterType, ConnectionString, false)
        {
           
        }

                /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="items">Collection of data to be rendered</param>
        /// <param name="Properties">Comma separated properties to be rendered</param>
        /// <param name="IdPropertyName"></param>
        public dhtmlxDataJsonConnector(IEnumerable items, string Properties, string IdPropertyName)
        {
            this._Request = new DataRequestSDT(this, items, Properties, IdPropertyName, "");
            this._Request.EnableSingleRecordSelect = true;
        }


        /// <summary>
        /// Creates new instance of dhtmlxDataViewConnector
        /// </summary>
        /// <param name="SelectQuery">Select query to use for data retrieval</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name (nullable)</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">ConnectionString for connection to database engine</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public dhtmlxDataJsonConnector(string SelectQuery, string PrimaryKeyColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, bool asIs)
            : base()
        {
            this._Request = new DataRequestSDT(this, SelectQuery, PrimaryKeyColumnName, "", AdapterType, ConnectionString, asIs);
            this._Request.EnableSingleRecordSelect = true;
        }
       

        /// <summary>
        /// Creates collection of dhtmlxDataViewDataItem objects from DataTable provided
        /// </summary>
        /// <param name="Rows">Table to create dhtmlxComboItem objects from</param>
        /// <returns>Collection of dhtmlxComboItem objects</returns>
        protected override List<dhtmlxDataJsonConnectorDataItem> CreateDataItems(System.Data.DataTable Rows)
        {
            var items = new List<dhtmlxDataJsonConnectorDataItem>();
            for (int i = 0; i < Rows.Rows.Count; i++)
            {
                var dataItem = new dhtmlxDataJsonConnectorDataItem();
                if (this.Request.PrimaryKeyField != null)
                    dataItem.ID = Convert.ToString(Rows.Rows[i][this.Request.PrimaryKeyField.ExternalName]);
                for (var j = 0; j < Rows.Columns.Count; j++)
                {
                    if (!(this._Request.IdAppended && (Rows.Columns[j].ColumnName == this.Request.PrimaryKeyField.ExternalName)))
                        dataItem.DataFields.Add(Rows.Columns[j].ColumnName, Tools.ConvertToString(Rows.Rows[i][Rows.Columns[j]]));
                }
                dataItem.Index = i + this.Request.StartIndex;
                items.Add(dataItem);
            }

            return items;
           

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        protected override List<dhtmlxDataJsonConnectorDataItem> _CreateDataItems(System.Collections.IEnumerable objects, Dictionary<string, System.Reflection.PropertyInfo> properties)
        {
            var items = new List<dhtmlxDataJsonConnectorDataItem>();
            int i = 0;
            foreach (var item in objects)
            {
                var dataItem = new dhtmlxDataJsonConnectorDataItem();
                if (this.Request.PrimaryKeyField != null && properties.ContainsKey(this.Request.PrimaryKeyField.InternalName))
                    dataItem.ID = Convert.ToString(properties[this.Request.PrimaryKeyField.InternalName].GetValue(item, null));

                foreach (var p in properties)
                {
                    if (!(this._Request.IdAppended && (p.Key == this.Request.PrimaryKeyField.ExternalName)))
                    {

                        dataItem.DataFields.Add(p.Key, Tools.ConvertToString(p.Value.GetValue(item, null)));
                    }
                }

                dataItem.Index = i + this.Request.StartIndex;
                i++;
                items.Add(dataItem);
            }

            return items;
        }

        /// <summary>
        /// Renders processing results into current response
        /// </summary>
        /// <param name="response">HttpResponse object where to put results to</param>
        public override void RenderResponse(HttpResponse response)
        {
            response.Output.NewLine = "\n";
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering response");
#endif
            #endregion
            this.RenderResponseHeader(response);
            StringBuilder sb = new StringBuilder();
            var xWriter = new dhtmlxJSONWriter(sb);
            this.Render(xWriter);
            
            response.Write(xWriter.GetResult());
            
        }

        /// <summary>
        /// Renders and prepares xml specific headers
        /// </summary>
        /// <param name="response">HttpResponse object to use</param>
        protected override void RenderResponseHeader(HttpResponse response)
        {
            response.ContentType = "text/html";
           
        }

        /// <summary>
        /// Renders results of data actions into XmlWriter provided
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render response to</param>
        /// <param name="ResultsToRender">Collection of DataAction object to render</param>
        public override void RenderActions(IdhtmlxWriter xWriter, IEnumerable<DataAction> ResultsToRender)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Rendering data actions: [" + Tools.Join(ResultsToRender, ", ") + "]");
#endif
            #endregion


            

            var is_xml = false;
            foreach (DataAction actionResult in ResultsToRender)
            {
                if (actionResult.ActionProtocol == ActionProtocol.Standart)
                {
                    is_xml = true;
                    break;
                }
            }

            var xml = new dhtmlxXMLWriter(new StringBuilder(), null);
            
            if (is_xml)
            {
                var req = HttpContext.Current.Response;
                req.ContentType = "text/xml";
                req.Write("<?xml version=\"1.0\" encoding=\"" + req.HeaderEncoding.BodyName + "\"?>");
                xml.WriteStartElement("data");
                
            }

            if (this.HasBeforeOutputHandler)
            {
                #region LOG ENTRY
                #if !NO_LOG
                Log.WriteLine(this, "Calling BeforeOutput event");
                #endif
                #endregion
                this.FireBeforeOutputEvent(this, new RenderEventArgs(xWriter));             
            }

            
            foreach (DataAction actionResult in ResultsToRender)
            {
                if (actionResult.ActionProtocol == ActionProtocol.SDT)
                {
                    if (actionResult.ActionType == ActionType.Error)
                        xWriter.WriteRawString("false");
                    else
                        xWriter.WriteRawString("true");
                    if (actionResult.ActionType == ActionType.Inserted)
                        xWriter.WriteRawString('\n' + Convert.ToString(actionResult.PostoperationalPrimaryKeyValue));
                }
                else
                {
                                 
                    xml.WriteStartElement("action");

                    xml.WriteAttribute("type", actionResult.ActionType == ActionType.Custom ? actionResult.CustomActionName : this.Request.ConvertActionType(actionResult.ActionType));
                    xml.WriteAttribute("sid", Convert.ToString(actionResult.PrimaryKeyValue));
                    xml.WriteAttribute("tid", Convert.ToString(actionResult.PostoperationalPrimaryKeyValue));
                    foreach (KeyValuePair<string, string> attrib in actionResult.CustomAttribs)
                        xml.WriteAttribute(attrib.Key, attrib.Value);
                    if (!string.IsNullOrEmpty(actionResult.Details))
                        xml.WriteString(actionResult.Details);

                    xml.WriteEndElement();
                                 
                }
            }
            if (is_xml)
            { 
                xml.WriteEndElement();
                (xWriter as dhtmlxJSONWriter).WriteRawString(xml.GetResult());
            }


            if (this.HasEndHandler)
            {
                #region LOG ENTRY
#if !NO_LOG
                Log.WriteLine(this, "Calling End event");
#endif
                #endregion
                this.FireEndEvent(this, new RenderEventArgs(xWriter));
            }
        }

        /// <summary>
        /// Writes begin tags of response header
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void BeginRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            xWriter.WriteStartElement("data");
            if (this.Request.StartIndex == 0)
                xWriter.WriteAttribute("total_count", TotalRowsCount.ToString());
            else
                xWriter.WriteAttribute("pos", this.Request.StartIndex.ToString());
            RenderSecurityKey(xWriter);
            xWriter.WriteRawString("\"data\":");
            (xWriter as dhtmlxJSONWriter).WriteStartArray();
    
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="xWriter"></param>
        protected override void RenderSections(IdhtmlxWriter xWriter)
        {
            var sections = new string[this.Sections.Count];
            int i = 0;

            foreach (var sec in this.Sections)
            {
                sections[i++] = string.Format(", \"{0}\":{1}", sec.Key, sec.Value);

            }
            xWriter.WriteRawString(string.Join(",", sections));
        }

        /// <summary>
        /// Writes end tags of response header
        /// </summary>
        /// <param name="xWriter">IdhtmlxWriter to render content to</param>
        /// <param name="TotalRowsCount">Total amount of rows available</param>
        protected override void EndRenderContent(IdhtmlxWriter xWriter, int TotalRowsCount)
        {
            (xWriter as dhtmlxJSONWriter).WriteEndArray();
            RenderSections(xWriter);
            xWriter.WriteEndElement();
        }
    }

            
	
}

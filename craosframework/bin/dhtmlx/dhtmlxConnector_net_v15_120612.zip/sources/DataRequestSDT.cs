﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Collections.Specialized;
using System.Data;
using System.Xml;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Bridge class between connectors and database adapters. Class is responsible for parsing client request and processing basic data operations (sorting, filtering, selecting etc.)
    /// DataRequestSDT supports simple data transfer protocol
    /// </summary>
    public class DataRequestSDT : DataRequest
    {
        /// <summary>
        /// Creates new instance of DataRequest
        /// </summary>
        /// <param name="Connector">Connector to use for results output</param>
        /// <param name="SelectQuery">Select query to use for data requests</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name. Used to identify single row</param>
        /// <param name="ParentIDColumnName">ForeignKey column name. Used to link child rows to parents</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">DatabaseAdapter connection string</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public DataRequestSDT(IdhtmlxConnector Connector, string SelectQuery, string PrimaryKeyColumnName, string ParentIDColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString, bool asIs)
            : base(Connector, SelectQuery, PrimaryKeyColumnName, ParentIDColumnName, AdapterType, ConnectionString, asIs)
        {
           
        }

        /// <summary>
        /// Creates new instance of DataRequest
        /// </summary>
        /// <param name="Connector">Connector to use for results output</param>
        /// <param name="SelectQuery">Select query to use for data requests</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name. Used to identify single row</param>
        /// <param name="ParentIDColumnName">ForeignKey column name. Used to link child rows to parents</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        /// <param name="asIs">Defines whether connector should parse Sql query to generate create/delete/update queries, or use it without processing</param>
        public DataRequestSDT(IdhtmlxConnector Connector, string SelectQuery, string PrimaryKeyColumnName, string ParentIDColumnName, IdhtmlxDatabaseAdapter Adapter, bool asIs)
            : base(Connector, SelectQuery, PrimaryKeyColumnName, ParentIDColumnName, Adapter, asIs)
        {
           
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="data"></param>
        /// <param name="Columns"></param>
        /// <param name="PrimaryKeyColumnName"></param>
        /// <param name="ParentIDColumnName"></param>
        public DataRequestSDT(IdhtmlxConnector parent, System.Collections.IEnumerable data, string Columns, string PrimaryKeyColumnName, string ParentIDColumnName)
            :base(parent, data, Columns, PrimaryKeyColumnName, ParentIDColumnName)
        {
         
        }


        /// <summary>
        /// Creates new instance of DataRequest
        /// </summary>
        /// <param name="Connector">Connector to use for results output</param>
        /// <param name="TableName">Table name to run queries against to</param>
        /// <param name="Columns">Columns to include into result</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name. Used to identify single row</param>
        /// <param name="ParentIDColumnName">ForeignKey column name. Used to link child rows to parents</param>
        /// <param name="Adapter">Adapter to use for communication with database engine</param>
        public DataRequestSDT(IdhtmlxConnector Connector, string TableName, string Columns, string PrimaryKeyColumnName, string ParentIDColumnName, IdhtmlxDatabaseAdapter Adapter)
            : base(Connector, TableName, Columns, PrimaryKeyColumnName, ParentIDColumnName, Adapter)
        {
            
        }

        /// <summary>
        /// Creates new instance of DataRequest
        /// </summary>
        /// <param name="Connector">Connector to use for results output</param>
        /// <param name="TableName">Table name to run queries against to</param>
        /// <param name="Columns">Columns to include into result</param>
        /// <param name="PrimaryKeyColumnName">PrimaryKey column name. Used to identify single row</param>
        /// <param name="ParentIDColumnName">ForeignKey column name. Used to link child rows to parents</param>
        /// <param name="AdapterType">Type of adapter to use for communication with database engine</param>
        /// <param name="ConnectionString">DatabaseAdapter connection string</param>
        public DataRequestSDT(IdhtmlxConnector Connector, string TableName, string Columns, string PrimaryKeyColumnName, string ParentIDColumnName, dhtmlxDatabaseAdapterType AdapterType, string ConnectionString)
            : base(Connector, TableName, Columns, PrimaryKeyColumnName, ParentIDColumnName, AdapterType,  ConnectionString)
        {
           
        }

        /// <summary>
        /// Gets type of current request
        /// </summary>
        /// <param name="QueryString">QueryString collection for current request</param>
        /// <returns>DataRequestType value that represents current request type (Select or Edit)</returns>
        public override DataRequestType GetCurrentMode(NameValueCollection QueryString)
        {

            if (QueryString["action"] == null)
            {
                return base.GetCurrentMode(QueryString);
            }
            else
            {
                if(QueryString["action"] == "get")
                    return DataRequestType.Select;  
                return DataRequestType.SDT;                        
            }
                
        }

        /// <summary>
        /// Processes client request and performs operations requested by client components
        /// </summary>
        /// <param name="QueryString">QueryString collection of current request</param>
        /// <param name="Form">Form collection fof current request</param>
       public override void ProcessRequest(NameValueCollection QueryString, NameValueCollection Form)
        {
            #region LOG ENTRY
#if !NO_LOG
            Log.WriteLine(this, "Processing client request. QueryString: " + QueryString.ToString() + ", Form: " + Form);
#endif
            #endregion
            this._RequestType = this.GetCurrentMode(QueryString);
            ConnectorSecurity.CheckCSRF(this._RequestType);
            switch(this.RequestType)
            {
                //SELECTS
                case DataRequestType.Select:
                    UpdateSelectParams(QueryString);
                    break;
                case DataRequestType.SDT:
                    if (QueryString["action"] != null)
                    {
                        var form = new NameValueCollection(Form.Count + 1, Form);

                        form.Add("action", QueryString["action"]);
                        this.ProcessEditRequest(QueryString, form);
                    }
                    break;
                //UPDATES, INSERTS, DELETES
                case DataRequestType.Edit:
                    this.ProcessEditRequest(QueryString, Form);
                break;
                //SOMETHING UNEXPECTED
                default:
                    throw new NotImplementedException(this.RequestType.ToString() + " mode behavior has not been implemented yet!");
            }
        }


       /// <summary>
       /// Converts data actions from query string format to DataAction objects collection
       /// </summary>
       /// <param name="QueryString">QueryString collection that contains client data actions</param>
       /// <returns>Collection of DataAction objects</returns>
       protected override List<DataAction> ParseDataActions(NameValueCollection QueryString)
       {
           if (QueryString["action"] == null)
               return base.ParseDataActions(QueryString);

           var actionType = this.ParseActionType(QueryString["action"]);
           if (actionType == ActionType.Custom)
           {
               switch (QueryString["action"])
               {
                   case "insert":
                       actionType = ActionType.Inserted;
                       break;
                   case "delete":
                       actionType = ActionType.Deleted;
                       break;
                   case "update":
                       actionType = ActionType.Updated;
                       break;
                   default :
                       actionType = ActionType.Custom;
                       break;
               }
           }
           List<DataAction> results = new List<DataAction>();
           #region LOG ENTRY
#if !NO_LOG
           Log.WriteLine(this, "Now parsing data action for record with id=" + QueryString["id"] + ".");
#endif
           #endregion
           DataAction action;
           if (actionType == ActionType.Custom)//custom action has another set of constructor parameters
               action = new DataAction(
                       QueryString["id"],
                       this.TableName,
                       GetRowValues(QueryString, null),
                       GetUserDataValues(QueryString, null),
                       this.PrimaryKeyField,
                       QueryString["id"]);         
           else             
               action = new DataAction(//create data action of predefined type
                       actionType,
                       this.TableName,
                       GetRowValues(QueryString, null),
                       GetUserDataValues(QueryString, null),
                       this.PrimaryKeyField,
                       QueryString["id"]);

           action.ActionProtocol = ActionProtocol.SDT;
           results.Add(action);
                        
#region LOG ENTRY
#if !NO_LOG
           Log.WriteLine(this, "Parsed new action: " + results.Last().ToString());
#endif
#endregion             
          
           return results;
       }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace dhtmlxConnectors
{
    /// <summary>
    /// 
    /// </summary>
    public class ObjectAdapter: IdhtmlxDatabaseAdapter
    {
        /// <summary>
        /// 
        /// </summary>
        public IEnumerable Data { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FieldExpression"></param>
        /// <returns></returns>
        public Field ParseField(string FieldExpression)
        {
            return new TableField(FieldExpression != null ? FieldExpression.Trim() : "");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetData()
        {
            return Data;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ConnectionString
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="Rules"></param>
        /// <param name="groupBy"></param>
        /// <param name="having"></param>
        /// <returns></returns>
        public int ExecuteGetCountQuery(string TableName, List<Rule> Rules, string groupBy, string having)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="Rules"></param>
        /// <returns></returns>
        public int ExecuteGetCountQuery(string TableName, List<Rule> Rules)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public int ExecuteGetCountQuery(string query)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="RequestedFields"></param>
        /// <param name="Rules"></param>
        /// <param name="OrderBy"></param>
        /// <param name="StartIndex"></param>
        /// <param name="Count"></param>
        /// <param name="GroupBy"></param>
        /// <param name="Having"></param>
        /// <returns></returns>
        public System.Data.DataTable ExecuteSelectQuery(string TableName, IEnumerable<Field> RequestedFields, List<Rule> Rules, List<OrderByStatement> OrderBy, int StartIndex, int Count, string GroupBy, string Having)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="PrimaryKeyField"></param>
        /// <param name="PrimaryKeyValue"></param>
        public void ExecuteDeleteQuery(string TableName, Field PrimaryKeyField, object PrimaryKeyValue)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="NewColumnValues"></param>
        /// <param name="PrimaryKeyField"></param>
        /// <param name="PrimaryKeyValue"></param>
        public void ExecuteUpdateQuery(string TableName, Dictionary<Field, string> NewColumnValues, Field PrimaryKeyField, object PrimaryKeyValue)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="ColumnValues"></param>
        /// <param name="PrimaryKeyField"></param>
        /// <param name="PrimaryKeyValue"></param>
        /// <param name="AllFields"></param>
        /// <returns></returns>
        public object ExecuteInsertQuery(string TableName, Dictionary<Field, string> ColumnValues, Field PrimaryKeyField, object PrimaryKeyValue, dhtmlxFieldsCollection AllFields)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <param name="TableName"></param>
        /// <param name="RequestedFields"></param>
        /// <param name="Rules"></param>
        /// <param name="OrderBy"></param>
        /// <param name="StartIndex"></param>
        /// <param name="Count"></param>
        /// <param name="GroupBy"></param>
        /// <param name="Having"></param>
        /// <param name="queryType"></param>
        public void ParseSqlQuery(string sqlQuery, out string TableName, out IEnumerable<Field> RequestedFields, out List<Rule> Rules, out List<OrderByStatement> OrderBy, out int StartIndex, out int Count, out string GroupBy, out string Having, DataRequest.SourceType queryType)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="FieldName"></param>
        /// <returns></returns>
        public bool IsFieldName(string FieldName)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        public bool SupportsTransactions
        {
            get { throw new NotImplementedException(); }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Query"></param>
        public void ExecuteNonQuery(string Query)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Query"></param>
        /// <returns></returns>
        public object ExecuteScalar(string Query)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Query"></param>
        /// <returns></returns>
        public System.Data.DataTable ExecuteSelectQuery(string Query)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        public void BeginTransaction()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        public void CommitTransaction()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 
        /// </summary>
        public void RollbackTransaction()
        {
            throw new NotImplementedException();
        }
    }
}

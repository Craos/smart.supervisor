﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Reflection;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Helper class for rendering object collections
    /// </summary>
    internal class ObjectParser
    {
        /// <summary>
        /// Get properties from the object instance
        /// </summary>
        /// <param name="source"></param>
        /// <param name="targetProperties"></param>
        /// <returns></returns>
        public Dictionary<string, PropertyInfo> GetProperties(object source, IEnumerable<string> targetProperties)
        {
            object first = source;
            var res = new Dictionary<string, PropertyInfo>();
            if (first == default(object))
                return res;

            PropertyInfo[] sourProperties = (first.GetType()).GetProperties();

            var key = sourProperties.FirstOrDefault(a => a.Name.ToLower() == "key");
            var label = sourProperties.FirstOrDefault(a => a.Name.ToLower() == "label");

            foreach (var p in targetProperties)
            {
                if(!string.IsNullOrEmpty(p))
                    res.Add(p, sourProperties.FirstOrDefault(s => s.Name == p));
            }
            return res.Where(p => p.Value != null).ToDictionary(p => p.Key, p => p.Value);

        }
        
        /// <summary>
        /// Get properties from the object instance
        /// </summary>
        /// <param name="source"></param>
        /// <param name="targetProperties"></param>
        /// <param name="additional"></param>
        /// <returns></returns>
        public Dictionary<string, PropertyInfo> GetProperties(object source, IEnumerable<string> targetProperties, params string[] additional)
        {
            return GetProperties(source, targetProperties.Concat(additional.Where( a => !targetProperties.Contains(a))));

        }
        /// <summary>
        /// Get properties from the object instance
        /// </summary>
        /// <param name="source"></param>
        /// <param name="targetProperties"></param>
        /// <param name="additional"></param>
        /// <returns></returns>
        public Dictionary<string, PropertyInfo> GetProperties(object source, IEnumerable<Field> targetProperties, params Field[] additional)
        {
            return GetProperties(source, targetProperties.Concat(additional.Distinct().Where(a => !targetProperties.Contains(a))));

        }
        /// <summary>
        /// Get properties from the object instance
        /// </summary>
        /// <param name="source"></param>
        /// <param name="targetProperties"></param>
        /// <returns></returns>
        public Dictionary<string, PropertyInfo> GetProperties(object source, IEnumerable<Field> targetProperties)
        {
            return GetProperties(source, targetProperties.Where(p => p != null).Select(p => p.InternalName));

        }

   
    }
}

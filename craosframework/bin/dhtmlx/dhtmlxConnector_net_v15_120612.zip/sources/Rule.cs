﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Base class for WHERE statements
    /// </summary>
    public abstract class Rule
    {
    }
}

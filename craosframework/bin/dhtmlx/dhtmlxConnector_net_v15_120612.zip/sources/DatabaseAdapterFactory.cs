﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dhtmlxConnectors
{
    /// <summary>
    /// Factory class to create instances of different dhtmlxDatabaseAdapters
    /// throws: NotImplementedException
    /// </summary>
    public static class DatabaseAdapterFactory
    {
        /// <summary>
        /// Creates dhtmlxDatabaseAdapter instance
        /// </summary>
        /// <param name="type">dhtmlxDatabaseAdapterType</param>
        /// <returns>IdhtmlxDatabaseAdapter</returns>
        public static IdhtmlxDatabaseAdapter CreateAdapter(dhtmlxDatabaseAdapterType type)
        {
            IdhtmlxDatabaseAdapter result = null;
            switch (type)
            {

                case dhtmlxDatabaseAdapterType.SqlServer2005:
                    result = new MSSQLAdapter();
                    break;
                case dhtmlxDatabaseAdapterType.Odbc:
                    result = new OdbcAdapter();
                    break;
                case dhtmlxDatabaseAdapterType.OdbcOracle:
                    result = new OdbcOracleAdapter();
                    break;
                case dhtmlxDatabaseAdapterType.SQLite:
                    result = getByType("SQLiteAdapter");
                    break;
                case dhtmlxDatabaseAdapterType.MySQL:
                    result = getByType("MySQLAdapter");
                    break;
                case dhtmlxDatabaseAdapterType.PostgreSQL:
                    result = getByType("PostgreSQLAdapter");
                    break;
                case dhtmlxDatabaseAdapterType.Oracle:
                    result = getByType("OracleAdapter");
                    break;
                default:
                    throw new NotImplementedException("dhtmlxDatabaseAdapter for type " + type.ToString() + " has not been implemented yet!");
            }
            return result;
        }

        /// <summary>
        /// creating not native adapters instances by type name, so if some data providers wouldn`t be installed in the system
        /// their dhtmlxAdapters classes can be excluded from the project, so it can be recompiled if it`s needed
        /// </summary>
        /// <param name="type"></param>
        private static  IdhtmlxDatabaseAdapter getByType(string type)
        {
            Type t = AppDomain.CurrentDomain.GetAssemblies().SelectMany(a => a.GetTypes())
                                .FirstOrDefault(b => b.Name == type);
            if (t == null)
                throw new NotImplementedException("ado.net provider for "+type + " is not installed in your system!");

            return Activator.CreateInstance(t) as IdhtmlxDatabaseAdapter;
        }
    }


    /// <summary>
    /// Supported database adapters type
    /// </summary>
    public enum dhtmlxDatabaseAdapterType
    {
        /// <summary>
        /// Microsoft SQL Server 2000-2010
        /// </summary>
        SqlServer2005,
        /// <summary>
        /// ODBC adapter
        /// </summary>
        Odbc,
        /// <summary>
        /// ODBC Oracle adapter
        /// </summary>
        OdbcOracle,
        /// <summary>
        /// SQLite adapter
        /// </summary>
        SQLite,
        /// <summary>
        /// MySQL adapter
        /// </summary>
        MySQL,
        /// <summary>
        /// PostgreSQL adapter
        /// </summary>
        PostgreSQL,
        /// <summary>
        /// Oracle adapter
        /// </summary>
        Oracle,
        /// <summary>
        /// User-defined adapter
        /// </summary>
        Unknown
    }
}

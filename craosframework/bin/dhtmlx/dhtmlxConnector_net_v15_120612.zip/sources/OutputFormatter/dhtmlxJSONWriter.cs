﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Web;

using System.Text.RegularExpressions;
namespace dhtmlxConnectors
{
    /// <summary>
    /// connectors JSON response Writter
    /// </summary>
    public class dhtmlxJSONWriter : IdhtmlxWriter
    {
        
        private string _buffer = "";
        private JavaScriptSerializer serializer = null;
        private StringBuilder _sb = null;

       
        /// <summary>
        /// creates instance of dhtmlxXMLWriter
        /// </summary>
        /// <param name="builder">String builder</param>
        public dhtmlxJSONWriter(StringBuilder builder)
        {      
            serializer = new JavaScriptSerializer();
            _sb = builder;

        }
        /// <summary>
        /// writes start document tag
        /// </summary>
        /// <param name="title">start document tag</param>
        public virtual void WriteStartDocument(string title)
        {
            _buffer = "";
            WriteStartArray();
        }
        /// <summary>
        /// writes start document tag
        /// </summary>

        public virtual void WriteStartDocument()
        {
            _buffer = "";
            WriteStartArray();
        }
        /// <summary>
        /// writes start array sign
        /// </summary>
        public virtual void WriteStartArray()
        {
            
            _buffer += "[";
        }
        /// <summary>
        /// writes end array sign
        /// </summary>
        public virtual void WriteEndArray()
        {
            if (_buffer.EndsWith(","))
                _buffer = _buffer.Remove(_buffer.Length - 1);
            _buffer += "]";
            
        }
        /// <summary>
        /// writes xml attribute
        /// </summary>
        /// <param name="name">attribute name</param>
        /// <param name="value">attribute value</param>
        public virtual void WriteAttribute(string name, string value)
        {
            WriteField(name, value);
        }

        /// <summary>
        /// closes document tag
        /// </summary>
        public virtual void WriteEndDocument()
        {
            WriteEndArray();           
        }
        /// <summary>
        /// writes name-value field, in this case simple xml node with text content
        /// </summary>
        /// <param name="name">node name</param>
        /// <param name="value">node value</param>
        public virtual void WriteField(string name, string value)
        {
            _buffer += serializer.Serialize(name) + ":" + serializer.Serialize(value) + ",";
        }
        /// <summary>
        /// opens element tag
        /// </summary>
        /// <param name="title">element tag</param>
        public virtual void WriteStartElement(string title)
        {
            _buffer += "{";
        }
        /// <summary>
        /// opens element tag
        /// </summary>
        public virtual void WriteStartElement()
        {
            _buffer += "{";
        }
        /// <summary>
        /// closes element tag
        /// </summary>
        public virtual void WriteEndElement()
        {
            if(_buffer.EndsWith(","))
                _buffer = _buffer.Remove(_buffer.Length -1);
            _buffer += "},";
        }

        /// <summary>
        /// writes string
        /// </summary>
        /// <param name="value">Value</param>
        public virtual void WriteString(string value)
        {
            _buffer += serializer.Serialize(value);

        }
        /// <summary>
        /// returns result document
        /// </summary>
        /// <returns>string</returns>
        public virtual string GetResult()
        {
            if (_buffer.EndsWith(","))
                _buffer = _buffer.Remove(_buffer.Length - 1);
            var result = _buffer;
            _buffer = "";
            return result;
        }
        /// <summary>
        /// writes non escaped sting
        /// </summary>
        /// <returns>string</returns>
        public void WriteRawString(string value)
        {
            if (_buffer.EndsWith(",") && value.StartsWith(",") && value.Length > 0)
                value = value.Substring(1);
            _buffer += value;
        }



    }
}

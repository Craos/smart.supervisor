﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using dhtmlxConnectors;

namespace dhtmlxConnectors
{
    /// <summary>
    /// basic functionality for dhtmlxWritter
    /// </summary>
    public interface IdhtmlxWriter
    {
        /// <summary>
        /// Writes begin document symbol
        /// </summary>
        /// <param name="title">string</param>
        void WriteStartDocument(string title);
        /// <summary>
        /// Writes begin document symbol
        /// </summary> 
        void WriteStartDocument();
        /// <summary>
        /// Writes end document symbol
        /// </summary>
        void WriteEndDocument();
        /// <summary>
        /// Writes begining of element record symbol
        /// </summary>
        /// <param name="title">string</param>
        void WriteStartElement(string title);
        /// <summary>
        /// Writes begining of element record symbol
        /// </summary>
        void WriteStartElement();
        /// <summary>
        /// Writes end of element record symbol
        /// </summary>
        void WriteEndElement();
        /// <summary>
        /// Writes record field
        /// </summary>
        /// <param name="name">field name</param>
        /// <param name="value">field value</param>
        void WriteField(string name, string value);
        /// <summary>
        /// Writes string 
        /// </summary>
        /// <param name="value">value</param>
        void WriteString(string value);
        /// <summary>
        /// Writes record's attribute
        /// </summary>
        /// <param name="name">attribute name</param>
        /// <param name="value">attribute value</param>
        void WriteAttribute(string name, string value);
     
        /// <summary>
        /// Returns resulting string
        /// </summary>
        /// <returns>string</returns>
        string GetResult();

        /// <summary>
        /// Writes string without
        /// </summary>
        /// <param name="value"></param>
        void WriteRawString(string value);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Web;
namespace dhtmlxConnectors
{
    /// <summary>
    /// connectors XML response Writter
    /// </summary>
    public class dhtmlxXMLWriter : IdhtmlxWriter
    {

        // operations counter
        private int counter = 0;
        /// <summary>
        /// stores StringBuilder
        /// </summary>
        protected StringBuilder _sb = null;
        /// <summary>
        /// stores XmlWriter
        /// </summary>
        protected XmlWriter xWriter = null;
        /// <summary>
        /// getter for StringBuilder
        /// </summary>
        public StringBuilder StringBuilder
        {
            get { return _sb; }
                
        }
        private HttpResponse _response = null;
        /// <summary>
        /// gets instance of httpResponse
        /// </summary>
        public HttpResponse Response
        {
            get { return _response; }
        }
        private void check()
        {
            //flush xmlWriter to StringBuilder every 100 operations
            if (counter >= 100)
                xWriter.Flush();
        }
        private void update()
        {
            counter++;
            check();
        }
        /// <summary>
        /// creates instance of dhtmlxXMLWriter
        /// </summary>
        /// <param name="builder">String builder</param>
        /// <param name="response">HttpResponse</param>
        public dhtmlxXMLWriter(StringBuilder builder, HttpResponse response)
        {
            this._sb = builder;
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            XmlWriter writer = XmlWriter.Create(builder, settings);
            this.xWriter = writer;
            update();
            _response = response;
        }
        /// <summary>
        /// writes start document tag
        /// </summary>
        /// <param name="title">start document tag</param>
        public void WriteStartDocument(string title)
        {
            xWriter.WriteStartElement(title);
            update();
        }
        /// <summary>
        /// writes start document tag
        /// </summary>
        public void WriteStartDocument()
        {
            xWriter.WriteStartElement("");
            update();
        }
        /// <summary>
        /// writes xml attribute
        /// </summary>
        /// <param name="name">attribute name</param>
        /// <param name="value">attribute value</param>
        public void WriteAttribute(string name, string value)
        {
            xWriter.WriteAttributeString(name, value != null ? value : "");
            update();
        }

        /// <summary>
        /// closes document tag
        /// </summary>
        public void WriteEndDocument()
        {

            xWriter.WriteEndElement();
            
        }
        /// <summary>
        /// writes name-value field, in this case simple xml node with text content
        /// </summary>
        /// <param name="name">node name</param>
        /// <param name="value">node value</param>
        public void WriteField(string name, string value)
        {
            xWriter.WriteStartElement(name);
            xWriter.WriteCData(value != null ? value : "");
            xWriter.WriteEndElement();
            update();
        }
        /// <summary>
        /// opens element tag
        /// </summary>
        /// <param name="title">element tag</param>
        public void WriteStartElement(string title)
        {
            xWriter.WriteStartElement(title);
            update();
        }
        /// <summary>
        /// opens element tag
        /// </summary>
    
        public void WriteStartElement()
        {
            xWriter.WriteStartElement("");
            update();
        }
        /// <summary>
        /// closes element tag
        /// </summary>
        public void WriteEndElement()
        {
            xWriter.WriteEndElement();
            update();
        }

        /// <summary>
        /// writes string
        /// </summary>
        /// <param name="value">Calue</param>
        public void WriteString(string value)
        {
            xWriter.WriteCData(value);
            update();
        }
        /// <summary>
        /// closes writer and returns result document
        /// </summary>
        /// <returns>string</returns>
        public string GetResult()
        {
            xWriter.Close();
            var result = this._sb.ToString();
            _sb.Remove(0, _sb.Length);
            return result;
        }

        /// <summary>
        /// writes string value to output(not necessary xml)
        /// </summary>
        /// <param name="value">string</param>
        public void WriteRawString(string value)
        {
            //xWriter.Flush();
            xWriter.WriteRaw(value);
            update();
          //  _sb.Append(value);
        }
        /// <summary>
        /// cleares stringBuilder`s buffer
        /// </summary>
        /// <returns>string</returns>
        public void Reset()
        {
            _sb.Remove(0, _sb.Length);
        }
    }
}

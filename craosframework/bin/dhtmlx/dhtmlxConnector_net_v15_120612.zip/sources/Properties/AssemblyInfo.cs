﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("dhtmlxConnectors.NET")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Dinamenta, UAB")]
[assembly: AssemblyProduct("dhtmlxConnectors.NET")]
[assembly: AssemblyCopyright("Copyright © Dinamenta, UAB 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("55b51cd1-8d7e-4893-aa62-cceed76ef850")]

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]

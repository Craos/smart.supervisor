﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.OracleClient;


namespace dhtmlxConnectors
{
    /// <summary>
    /// Oracle compatible implementation of idhtmlxDatabaseAdapter interface
    ///  
    /// </summary>
    public class OracleAdapter : OdbcOracleAdapter, IdhtmlxDatabaseAdapter
    {
        /// <summary>
        /// Creates initialized opened IDbConnection object
        /// </summary>
        /// <param name="ConnectionString">ConnectionString to initialize connection by</param>
        /// <returns></returns>
        protected override IDbConnection CreateConnection(string ConnectionString)
        {
            return new OracleConnection(ConnectionString);
        }

        /// <summary>
        /// Creates IDbCommand object
        /// </summary>
        /// <param name="Query">Query to initialize command with</param>
        /// <param name="Connection">Connection to initialize command with</param>
        /// <returns>IDbCommand object</returns>
        protected override IDbCommand CreateCommand(string Query, IDbConnection Connection)
        {
            return new OracleCommand(Query, Connection as OracleConnection);
        }

        /// <summary>
        /// Creates IDbDataAdapter
        /// </summary>
        /// <param name="Command">Command to initialize adapter with</param>
        /// <returns>IDbDataAdapter object</returns>
        protected override IDbDataAdapter CreateDataAdapter(IDbCommand Command)
        {
            return new OracleDataAdapter(Command as OracleCommand);
        }       
    }
}